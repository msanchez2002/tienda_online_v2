package m13_actfinal;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class FacturaDAOImpl {

    public FacturaDAOImpl() {
    }
    
    public void insertarFacturas(Factura f) throws SQLException, ClassNotFoundException{
        // Conectar a la base de datos
        Connexio conexion = new Connexio();

        // Preparar la sentencia SQL
        String sql = "INSERT INTO facturas (Fecha, PrecioTotal, IVA) VALUES (?, ?, ?)";
        PreparedStatement sentencia = conexion.prepararSentencia(sql);
        sentencia.setTimestamp(1, f.getDate());
        sentencia.setFloat(2, f.getPrecioTotal());
        sentencia.setFloat(3, f.getIVA());

        // Ejecutar la sentencia
        sentencia.executeUpdate();

        // Cerrar la conexión a la base de datos
        conexion.cerrar();
    }
    
    public int obtenerIdFactura(Factura f) throws SQLException, ClassNotFoundException{
        int id = 0;
        
        Connexio conexion = new Connexio();

        String sql = "SELECT id FROM facturas WHERE fecha=? AND PrecioTotal=?";
        PreparedStatement sentencia = conexion.prepararSentencia(sql);
        sentencia.setTimestamp(1, f.getDate());
        sentencia.setFloat(2, f.getPrecioTotal());
        ResultSet resultSet = sentencia.executeQuery();

        // Agregar los resultados a la tabla
        if (resultSet.next()) {
            id = resultSet.getInt(1);
        }

        // Cerrar la conexión a MySQL
        resultSet.close();
        sentencia.close();
        conexion.cerrar();

        conexion.cerrar();
        
        return id;
    }
}
