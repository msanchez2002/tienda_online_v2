package m13_actfinal;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import java.sql.Date;
import java.text.SimpleDateFormat;

public class PantallaPrincipal extends javax.swing.JFrame {

    Gestor gestor;

    static private DefaultListModel<String> modeloLista;

    static HashMap<String, Integer> numElementos = new HashMap<>();

    static int numActual = 0;

    static List<Producto> productosList;

    static float precioSinIVA = 0;
    static float precioIVA = 0;
    static float precioTotal = 0;
    static final float IVA = 0.21f;

    static JLabel labelPrecioSinIVA = new JLabel("Label 1");
    static JLabel labelPrecioIVA = new JLabel("Label 2");
    static JLabel labelPrecioTotal = new JLabel("Label 3");

    static String nombreProductoBorrado;
    static int numProducto;
    boolean admin;

    static void add(JTabbedPane tabbedPane, String label) {
        int count = tabbedPane.getTabCount();
        JPanel panel = new JPanel(new GridLayout(0, 2));

        for (int i = 0; i < productosList.size(); i++) {
            if (label.equals(productosList.get(i).getCategoria())) {
                JButton button = new JButton(productosList.get(i).getNombre());
                button.addMouseListener(createMouseAdapter());
                panel.add(button);
            }
        }
        tabbedPane.addTab(label, panel);
    }

    public PantallaPrincipal(boolean admin) {
        precioSinIVA = 0;
        initComponents();
        this.admin = admin;
        if (admin) {
            initMenuBar();
        }
        actualizarPrecio();
        modeloLista = new DefaultListModel<>();
        jPanelLista.setPreferredSize(new Dimension(250, 300));

        try {
            Connexio conn = new Connexio();

            String query = "SELECT * FROM productos ORDER BY nombre";

            productosList = new ArrayList();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            while (rs.next()) {
                productosList.add(new Producto(rs.getString("nombre"), rs.getFloat("Precio"),
                        rs.getString("categoria")));
            }

            ProductoDAOImpl productoDAO = new ProductoDAOImpl();
            String[] arrayCategorias = productoDAO.obtenerCategoriaProductos();

            for (int i = 0; i < arrayCategorias.length; i++) {
                add(jTabbed, arrayCategorias[i]);
            }

            JPanel panel = new JPanel(new GridLayout(0, 2));

            conn.cerrar();

        } catch (SQLException ex) {
            ex.printStackTrace();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(PantallaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        }

        JList<String> lista = new JList<String>(modeloLista);

        JButton botonEliminar = new JButton("Eliminar");
        botonEliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int indiceSeleccionado = lista.getSelectedIndex();
                if (indiceSeleccionado >= 0) {
                    try {
                        ProductoDAOImpl productoDAO = new ProductoDAOImpl();
                        String elementoSeleccionado = modeloLista.getElementAt(indiceSeleccionado);

                        String[] nombreProducto = modeloLista.get(indiceSeleccionado).split(" x");
                        nombreProductoBorrado = nombreProducto[0];
                        numProducto = numElementos.get(nombreProductoBorrado);

                        float precio = productoDAO.precioProducto(nombreProductoBorrado);
                        precioSinIVA -= (precio * numProducto);
                        actualizarPrecio();

                        numElementos.remove(elementoSeleccionado);
                        modeloLista.removeElementAt(indiceSeleccionado);
                        precio = 0;
                    } catch (SQLException ex) {
                        Logger.getLogger(PantallaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (ClassNotFoundException ex) {
                        Logger.getLogger(PantallaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        });
        JButton botonEliminarTodo = new JButton("Eliminar Todo");
        botonEliminarTodo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                vaciarTodo();
            }
        });

        jPanelLista.setLayout(new BorderLayout());
        jPanelLista.add(new JScrollPane(lista), BorderLayout.CENTER);
        JPanel panelSur = new JPanel(new GridLayout(2, 1));
        panelSur.add(botonEliminar);
        panelSur.add(botonEliminarTodo);
        jPanelLista.add(panelSur, BorderLayout.SOUTH);

        jPanel3.setLayout(new BorderLayout());
        jPanel3.add(labelPrecioSinIVA, BorderLayout.NORTH);
        jPanel3.add(labelPrecioIVA, BorderLayout.CENTER);
        jPanel3.add(labelPrecioTotal, BorderLayout.SOUTH);

        this.getContentPane().setPreferredSize(new Dimension(600, 400));
        this.pack();

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {

        gestor = new Gestor();

        jPanelLista = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jToggleButton1 = new javax.swing.JToggleButton();
        jToggleButton2 = new javax.swing.JToggleButton();
        jTabbed = new javax.swing.JTabbedPane();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout jPanelListaLayout = new javax.swing.GroupLayout(jPanelLista);
        jPanelLista.setLayout(jPanelListaLayout);
        jPanelListaLayout.setHorizontalGroup(
                jPanelListaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanelListaLayout.setVerticalGroup(
                jPanelListaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 177, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
                jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 246, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
                jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 95, Short.MAX_VALUE)
        );

        jToggleButton1.setText("Pagar");
        jToggleButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {

                if (modeloLista.getSize() == 0) {
                    JOptionPane.showMessageDialog(null, "Introduce productos antes de pagar.");
                } else {

                    try {
                        FacturaDAOImpl facturaDAO = new FacturaDAOImpl();
                        ProductoDAOImpl productoDAO = new ProductoDAOImpl();
                        LineaFacturaDAOImpl lineaFacturaDAO = new LineaFacturaDAOImpl();

                        LocalDateTime localDateTime = LocalDateTime.now();
                        Timestamp sqlDateTemp = Timestamp.valueOf(localDateTime);
                        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                        String formattedDateTime = dateFormat.format(sqlDateTemp);
                        Timestamp sqlDate = Timestamp.valueOf(formattedDateTime);

                        DecimalFormatSymbols symbols = new DecimalFormatSymbols(Locale.getDefault());
                        symbols.setDecimalSeparator('.');
                        DecimalFormat df = new DecimalFormat("0.00", symbols);
                        float precioTotalFactura = Float.valueOf(df.format(precioTotal));

                        Factura factura = new Factura(sqlDate, precioTotalFactura, IVA);
                        facturaDAO.insertarFacturas(factura);

                        int idFactura = facturaDAO.obtenerIdFactura(factura);

                        for (Map.Entry<String, Integer> entry : numElementos.entrySet()) {
                            String nombre = entry.getKey();
                            Integer cantidad = entry.getValue();

                            float precio = productoDAO.precioProducto(nombre);
                            int idProducto = productoDAO.obtenerIdProductoPorNombre(nombre);
                            
                            float preciolf = precio*cantidad;
                            
                            LineaFactura lf = new LineaFactura(idFactura, idProducto, cantidad, preciolf);
                            
                            lineaFacturaDAO.insertarProducto(lf);
                        }

                    } catch (SQLException ex) {
                        Logger.getLogger(PantallaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (ClassNotFoundException ex) {
                        Logger.getLogger(PantallaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                    }

                    File directorio = new File("./facturas");
                    File[] archivos = directorio.listFiles();
                    int numFactura = archivos.length + 1;
                    File f = new File("./facturas/factura" + numFactura + ".txt");
                    try {
                        FileWriter w = new FileWriter(f);
                        StringBuilder sb = new StringBuilder();

                        sb.append("(NomEstabliment)").append("\n");

                        LocalDate fecha = LocalDate.now();
                        LocalTime hora = LocalTime.now();
                        LocalDateTime fechaHora = LocalDateTime.of(fecha, hora);
                        String patron = "HH:mm:ss - dd/MM/yyyy";
                        DateTimeFormatter formateador = DateTimeFormatter.ofPattern(patron);
                        String fechaFormateada = fechaHora.format(formateador);
                        sb.append("Fecha: " + fechaFormateada).append("\n");

                        Object[] elementos = modeloLista.toArray();
                        sb.append("-------------------------------\n");
                        for (Object elemento : elementos) {
                            sb.append(elemento.toString());
                            sb.append("\n");
                        }
                        sb.append("-------------------------------\n");
                        DecimalFormatSymbols symbols = new DecimalFormatSymbols(Locale.getDefault());
                        symbols.setDecimalSeparator('.');
                        DecimalFormat df = new DecimalFormat("0.00", symbols);
                        String formattedNumber = df.format(precioSinIVA);
                        sb.append("Precio: ").append(formattedNumber).append("\n");
                        formattedNumber = df.format(precioIVA);
                        sb.append("IVA(21%): ").append(formattedNumber).append("\n");
                        formattedNumber = df.format(precioTotal);
                        sb.append("Precio Total: ").append(formattedNumber).append("\n");

                        w.write(sb.toString());
                        w.close();

                        JOptionPane.showMessageDialog(null, "Factura" + numFactura + " creada.");
                        vaciarTodo();

                    } catch (IOException ex) {
                        Logger.getLogger(PantallaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        });

        jToggleButton2.setText("Cancelar");
        jToggleButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dispose();
                new LoginPantalla();
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                                .addGap(10, 10, 10)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                        .addComponent(jPanelLista, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                        .addGroup(layout.createSequentialGroup()
                                                .addGap(2, 2, 2)
                                                .addComponent(jToggleButton1)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jToggleButton2)))
                                .addGap(18, 18, 18)
                                .addComponent(jTabbed, javax.swing.GroupLayout.DEFAULT_SIZE, 190, Short.MAX_VALUE)
                                .addContainerGap())
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jTabbed)
                                        .addGroup(layout.createSequentialGroup()
                                                .addComponent(jPanelLista, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 26, Short.MAX_VALUE)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                        .addComponent(jToggleButton1)
                                                        .addComponent(jToggleButton2))))
                                .addContainerGap())
        );

        pack();
    }

    public Set<String> categorias(final List<Producto> productos) {
        Set<String> categorias = new HashSet<>();
        for (final Producto producto : productos) {
            categorias.add(producto.getCategoria());
        }
        return categorias;
    }

    static public MouseAdapter createMouseAdapter() {
        return new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                ProductoDAOImpl productoDAO = new ProductoDAOImpl();
                JButton boton = (JButton) e.getSource();
                String nombreElemento = boton.getText();
                int sizeNombre = nombreElemento.length();
                if (modeloLista.size() == 0) {
                    try {
                        float precio = productoDAO.precioProducto(nombreElemento);
                        String texto = nombreElemento + " x1" + " - " + precio;
                        precioSinIVA += precio;
                        actualizarPrecio();
                        modeloLista.addElement(texto);
                        numElementos.put(nombreElemento, 1);
                    } catch (SQLException ex) {
                        Logger.getLogger(PantallaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (ClassNotFoundException ex) {
                        Logger.getLogger(PantallaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                    }
                } else {
                    boolean encontrado = false;
                    for (int i = 0; i < modeloLista.size(); i++) {
                        if (modeloLista.get(i).length() >= sizeNombre) {
                            if (modeloLista.get(i).substring(0, sizeNombre).equals(nombreElemento)) {
                                encontrado = true;
                                int indice = -1;
                                for (int j = 0; j < modeloLista.size(); j++) {
                                    if (modeloLista.get(j).startsWith(nombreElemento)) {
                                        indice = j;
                                        break;
                                    }
                                }
                                if (indice == -1) {
                                    System.out.println("No existe");
                                } else {
                                    int numActual = 1;
                                    if (numElementos.containsKey(nombreElemento)) {
                                        numActual = numElementos.get(nombreElemento);
                                        numActual++;
                                    }

                                    try {
                                        float precio = productoDAO.precioProducto(nombreElemento);

                                        DecimalFormatSymbols symbols = new DecimalFormatSymbols(Locale.getDefault());
                                        symbols.setDecimalSeparator('.');
                                        DecimalFormat df = new DecimalFormat("0.00", symbols);

                                        numElementos.put(nombreElemento, numActual);
                                        String formattedNumber = df.format(precio * numActual);
                                        String elementoActualizado = nombreElemento + " x" + numActual + " - " + precio + " - " + formattedNumber;
                                        precioSinIVA += precio;
                                        actualizarPrecio();
                                        modeloLista.setElementAt(elementoActualizado, indice);
                                    } catch (SQLException ex) {
                                        Logger.getLogger(PantallaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                                    } catch (ClassNotFoundException ex) {
                                        Logger.getLogger(PantallaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                                    }
                                }
                            }
                        }
                        if (encontrado) {
                            break;
                        }
                    }
                    if (!encontrado) {
                        try {
                            float precio = productoDAO.precioProducto(nombreElemento);
                            String texto = nombreElemento + " x1" + " - " + precio;
                            precioSinIVA += precio;
                            actualizarPrecio();
                            modeloLista.addElement(texto);
                            numElementos.put(nombreElemento, 1);
                        } catch (SQLException ex) {
                            Logger.getLogger(PantallaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                        } catch (ClassNotFoundException ex) {
                            Logger.getLogger(PantallaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                }
            }

        };

    }

    static public void actualizarPrecio() {
        DecimalFormat df = new DecimalFormat("0.00");
        String formattedNumber = df.format(precioSinIVA);
        labelPrecioSinIVA.setText("Precio: " + formattedNumber);
        precioIVA = precioSinIVA * IVA;
        formattedNumber = df.format(precioIVA);
        labelPrecioIVA.setText("IVA (" + (IVA * 100) + "%): " + formattedNumber);
        precioTotal = precioSinIVA + precioIVA;
        formattedNumber = df.format(precioTotal);
        labelPrecioTotal.setText("Precio Total: " + formattedNumber);
    }

    static public void vaciarTodo() {
        numElementos.clear();
        modeloLista.removeAllElements();
        precioSinIVA = 0;
        actualizarPrecio();
    }

    private void initMenuBar() {
        JMenuBar menuBar = new JMenuBar();
        JMenu menuAdministrar = new JMenu("Administrar");
        //-------------
        JMenu menuUsuario = new JMenu("Usuarios");
        JMenuItem menuItemInsertarUsuario = new JMenuItem("Insertar");
        menuItemInsertarUsuario.setActionCommand("InsertarUsuario");
        menuItemInsertarUsuario.addActionListener(gestor);
        //----
        JMenuItem menuItemMostrarUsuarios = new JMenuItem("Mostrar");
        menuItemMostrarUsuarios.setActionCommand("MostrarUsuario");
        menuItemMostrarUsuarios.addActionListener(gestor);
        //----
        JMenuItem menuItemEliminarUsuario = new JMenuItem("Eliminar");
        menuItemEliminarUsuario.setActionCommand("EliminarUsuario");
        menuItemEliminarUsuario.addActionListener(gestor);
        //--
        menuUsuario.add(menuItemInsertarUsuario);
        menuUsuario.add(menuItemMostrarUsuarios);
        menuUsuario.add(menuItemEliminarUsuario);
        menuAdministrar.add(menuUsuario);

        //-------------
        JMenu menuProducto = new JMenu("Productos");
        JMenuItem menuItemInsertarProducto = new JMenuItem("Insertar");
        menuItemInsertarProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                try {
                    JFrame frame = new JFrame();
                    frame.setPreferredSize(new Dimension(400, 350));
                    frame.setResizable(false);

                    GridBagLayout layout = new GridBagLayout();
                    frame.setLayout(layout);

                    ProductoDAOImpl productoDAO = new ProductoDAOImpl();

                    JLabel nombreLabel = new JLabel("Nombre: ");
                    JTextField nombreField = new JTextField(20);
                    JLabel precioLabel = new JLabel("Precio: ");
                    JTextField precioField = new JTextField(20);
                    JLabel categoriaLabel = new JLabel("Categoria: ");
                    String[] categorias = productoDAO.obtenerCategoriaProductos();
                    JComboBox<String> categoriasComboBox = new JComboBox<>(categorias);
                    JLabel otraCategoriaLabel = new JLabel("Otra:");
                    JCheckBox otraCategoriaCheckBox = new JCheckBox();
                    JLabel categoriaNuevaLabel = new JLabel("Categoria Nueva: ");
                    categoriaNuevaLabel.setVisible(false);
                    JTextField categoriaNuevaField = new JTextField(20);
                    categoriaNuevaField.setVisible(false);

                    otraCategoriaCheckBox.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                            if (otraCategoriaCheckBox.isSelected()) {
                                categoriaNuevaLabel.setVisible(true);
                                categoriaNuevaField.setVisible(true);
                                categoriaLabel.setVisible(false);
                                categoriasComboBox.setVisible(false);
                            } else {
                                categoriaNuevaLabel.setVisible(false);
                                categoriaNuevaField.setVisible(false);
                                categoriasComboBox.setVisible(true);
                                categoriaLabel.setVisible(true);
                            }
                        }
                    });

                    JButton insertarButton = new JButton("Insertar");

                    insertarButton.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {

                            try {
                                if (nombreField.getText().equals("")) {
                                    JOptionPane.showMessageDialog(null, "Tienes que introducir un nombre.");
                                } else if (precioField.getText().equals("")) {
                                    JOptionPane.showMessageDialog(null, "Tienes que introducir un precio.");
                                } else {

                                    String nombre = nombreField.getText();
                                    float precio = Float.parseFloat(precioField.getText());
                                    String categoria = "";

                                    if (otraCategoriaCheckBox.isSelected()) {
                                        if (categoriaNuevaField.getText().equals("")) {
                                            JOptionPane.showMessageDialog(null, "Tienes que introducir una nueva categoria.");
                                        } else {
                                            categoria = categoriaNuevaField.getText();
                                        }
                                    } else {
                                        categoria = (String) categoriasComboBox.getSelectedItem();
                                    }

                                    if (!categoria.equals("")) {
                                        ProductoDAOImpl productoDAO = new ProductoDAOImpl();
                                        productoDAO.insertarProducto(new Producto(nombre, precio, categoria));
                                        JOptionPane.showMessageDialog(null, "Inserción correcta.");
                                        frame.dispose();
                                        dispose();
                                        new PantallaPrincipal(admin).setVisible(true);
                                    }

                                }
                            } catch (NumberFormatException ex) {
                                JOptionPane.showMessageDialog(null, "Precio no valido.");
                            } catch (SQLException ex) {
                                JOptionPane.showMessageDialog(null, "El producto ya existe.");
                            } catch (ClassNotFoundException ex) {
                                ex.printStackTrace();
                                JOptionPane.showMessageDialog(null, "Error de connexión en la base de datos");
                            }
                        }
                    });

                    GridBagConstraints constraints = new GridBagConstraints();
                    constraints.gridx = 0;
                    constraints.gridy = 0;
                    constraints.insets = new Insets(0, 0, 20, 5);
                    constraints.anchor = GridBagConstraints.EAST;
                    frame.add(nombreLabel, constraints);

                    constraints.gridx = 1;
                    frame.add(nombreField, constraints);

                    constraints.gridx = 0;
                    constraints.gridy = 1;
                    frame.add(precioLabel, constraints);

                    constraints.gridx = 1;
                    frame.add(precioField, constraints);

                    constraints.gridx = 0;
                    constraints.gridy = 2;
                    frame.add(categoriaLabel, constraints);

                    constraints.gridx = 1;
                    constraints.anchor = GridBagConstraints.WEST;
                    frame.add(categoriasComboBox, constraints);

                    constraints.gridx = 0;
                    constraints.gridy = 3;
                    constraints.anchor = GridBagConstraints.EAST;
                    frame.add(otraCategoriaLabel, constraints);

                    constraints.gridx = 1;
                    constraints.anchor = GridBagConstraints.WEST;
                    frame.add(otraCategoriaCheckBox, constraints);

                    constraints.gridx = 0;
                    constraints.gridy = 4;
                    frame.add(categoriaNuevaLabel, constraints);

                    constraints.gridx = 1;
                    frame.add(categoriaNuevaField, constraints);

                    constraints.gridx = 0;
                    constraints.gridy = 5;
                    constraints.gridwidth = 3;
                    constraints.anchor = GridBagConstraints.CENTER;
                    frame.add(insertarButton, constraints);

                    frame.pack();
                    frame.setVisible(true);
                } catch (SQLException ex) {
                    Logger.getLogger(Gestor.class.getName()).log(Level.SEVERE, null, ex);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(Gestor.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
        //----
        JMenuItem menuItemMostrarProductos = new JMenuItem("Mostrar");
        menuItemMostrarProductos.setActionCommand("MostrarProducto");
        menuItemMostrarProductos.addActionListener(gestor);
        //----
        JMenuItem menuItemModificarProducto = new JMenuItem("Modificar");
        menuItemModificarProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JFrame frame = new JFrame();
                JPanel panel = new JPanel();
                frame.setPreferredSize(new Dimension(500, 485));
                frame.setResizable(false);

                ProductoDAOImpl productoDAO = new ProductoDAOImpl();
                List<Producto> lista = new ArrayList();
                int numProductos = 0;
                try {
                    lista = productoDAO.obtenerProductos();
                    numProductos = lista.size();
                } catch (SQLException ex) {
                    Logger.getLogger(Gestor.class.getName()).log(Level.SEVERE, null, ex);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(Gestor.class.getName()).log(Level.SEVERE, null, ex);
                }

                String[] nombreColumnas = {"Nombre", "Precio", "Categoria"};
                DefaultTableModel model = new DefaultTableModel(nombreColumnas, 0);
                JTable table = new JTable(model);
                table.getTableHeader().setReorderingAllowed(false);

                for (int i = 0; i < numProductos; i++) {
                    String[] rowData = {lista.get(i).getNombre(), String.valueOf(lista.get(i).getPrecio()), lista.get(i).getCategoria()};
                    model.addRow(rowData);
                }

                table.addMouseListener(new java.awt.event.MouseAdapter() {
                    public void mouseClicked(java.awt.event.MouseEvent evt) {
                        tableMouseClicked(evt);
                    }

                    private void tableMouseClicked(MouseEvent evt) {
                        ProductoDAOImpl productoDAO = new ProductoDAOImpl();
                        int column = 0;
                        int row = table.getSelectedRow();
                        String text = table.getModel().getValueAt(row, column).toString();
                        try {
                            int id = productoDAO.obtenerIdProductoPorNombre(text);
                            Producto productoViejo = productoDAO.obtenerProductoPorId(id);

                            JFrame frame = new JFrame();
                            frame.setPreferredSize(new Dimension(400, 350));
                            frame.setResizable(false);

                            GridBagLayout layout = new GridBagLayout();
                            frame.setLayout(layout);

                            JLabel nombreLabel = new JLabel("Nombre: ");
                            JTextField nombreField = new JTextField(20);
                            nombreField.setText(productoViejo.getNombre());
                            JLabel precioLabel = new JLabel("Precio: ");
                            JTextField precioField = new JTextField(20);
                            precioField.setText(String.valueOf(productoViejo.getPrecio()));
                            JLabel categoriaLabel = new JLabel("Categoria: ");
                            String[] categorias = productoDAO.obtenerCategoriaProductos();
                            JComboBox<String> categoriasComboBox = new JComboBox<>(categorias);
                            categoriasComboBox.setSelectedItem(productoViejo.getCategoria());
                            JLabel otraCategoriaLabel = new JLabel("Otra:");
                            JCheckBox otraCategoriaCheckBox = new JCheckBox();
                            JLabel categoriaNuevaLabel = new JLabel("Categoria Nueva: ");
                            categoriaNuevaLabel.setVisible(false);
                            JTextField categoriaNuevaField = new JTextField(20);
                            categoriaNuevaField.setVisible(false);

                            otraCategoriaCheckBox.addActionListener(new ActionListener() {
                                public void actionPerformed(ActionEvent e) {
                                    if (otraCategoriaCheckBox.isSelected()) {
                                        categoriaNuevaLabel.setVisible(true);
                                        categoriaNuevaField.setVisible(true);
                                        categoriaLabel.setVisible(false);
                                        categoriasComboBox.setVisible(false);
                                    } else {
                                        categoriaNuevaLabel.setVisible(false);
                                        categoriaNuevaField.setVisible(false);
                                        categoriaLabel.setVisible(true);
                                        categoriasComboBox.setVisible(true);
                                    }
                                }
                            });

                            JButton modificarButton = new JButton("Modificar");

                            modificarButton.addActionListener(new ActionListener() {
                                public void actionPerformed(ActionEvent e) {

                                    try {
                                        if (nombreField.getText().equals("")) {
                                            JOptionPane.showMessageDialog(null, "Tienes que introducir un nombre.");
                                        } else if (precioField.getText().equals("")) {
                                            JOptionPane.showMessageDialog(null, "Tienes que introducir un precio.");
                                        } else {

                                            String nombre = nombreField.getText();
                                            float precio = Float.parseFloat(precioField.getText());
                                            String categoria = "";

                                            if (otraCategoriaCheckBox.isSelected()) {
                                                if (categoriaNuevaField.getText().equals("")) {
                                                    JOptionPane.showMessageDialog(null, "Tienes que introducir una nueva categoria.");
                                                } else {
                                                    categoria = categoriaNuevaField.getText();
                                                }
                                            } else {
                                                categoria = (String) categoriasComboBox.getSelectedItem();
                                            }

                                            if (!categoria.equals("")) {
                                                ProductoDAOImpl productoDAO = new ProductoDAOImpl();
                                                Producto productoNuevo = new Producto(nombre, precio, categoria);
                                                if (productoDAO.modificarProductoPorId(id, productoNuevo)) {
                                                    JOptionPane.showMessageDialog(null, "Modificación correcta.");
                                                    frame.dispose();
                                                    dispose();
                                                    new PantallaPrincipal(admin).setVisible(true);
                                                } else {
                                                    JOptionPane.showMessageDialog(null, "Modificación incorrecta.");
                                                }
                                            }

                                        }
                                    } catch (NumberFormatException ex) {
                                        JOptionPane.showMessageDialog(null, "Precio no valido.");
                                    } catch (SQLException ex) {
                                        JOptionPane.showMessageDialog(null, "El producto ya existe.");
                                    } catch (ClassNotFoundException ex) {
                                        ex.printStackTrace();
                                        JOptionPane.showMessageDialog(null, "Error de connexión en la base de datos");
                                    }
                                }
                            });
                            GridBagConstraints constraints = new GridBagConstraints();
                            constraints.gridx = 0;
                            constraints.gridy = 0;
                            constraints.insets = new Insets(0, 0, 20, 5);
                            constraints.anchor = GridBagConstraints.EAST;
                            frame.add(nombreLabel, constraints);

                            constraints.gridx = 1;
                            frame.add(nombreField, constraints);

                            constraints.gridx = 0;
                            constraints.gridy = 1;
                            frame.add(precioLabel, constraints);

                            constraints.gridx = 1;
                            frame.add(precioField, constraints);

                            constraints.gridx = 0;
                            constraints.gridy = 2;
                            frame.add(categoriaLabel, constraints);

                            constraints.gridx = 1;
                            constraints.anchor = GridBagConstraints.WEST;
                            frame.add(categoriasComboBox, constraints);

                            constraints.gridx = 0;
                            constraints.gridy = 3;
                            constraints.anchor = GridBagConstraints.EAST;
                            frame.add(otraCategoriaLabel, constraints);

                            constraints.gridx = 1;
                            constraints.anchor = GridBagConstraints.WEST;
                            frame.add(otraCategoriaCheckBox, constraints);

                            constraints.gridx = 0;
                            constraints.gridy = 4;
                            frame.add(categoriaNuevaLabel, constraints);

                            constraints.gridx = 1;
                            frame.add(categoriaNuevaField, constraints);

                            constraints.gridx = 0;
                            constraints.gridy = 5;
                            constraints.gridwidth = 3;
                            constraints.anchor = GridBagConstraints.CENTER;
                            frame.add(modificarButton, constraints);

                            frame.pack();
                            frame.setVisible(true);
                        } catch (SQLException ex) {
                            JOptionPane.showMessageDialog(null, "Error eliminando producto.");
                        } catch (ClassNotFoundException ex) {
                            JOptionPane.showMessageDialog(null, "Error eliminando producto.");
                        }
                    }
                });

                JScrollPane scrollPane = new JScrollPane(table);
                panel.add(scrollPane);
                frame.add(panel);

                frame.pack();
                frame.setVisible(true);

            }
        });
        //----
        JMenuItem menuItemEliminarProducto = new JMenuItem("Eliminar");
        menuItemEliminarProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JFrame frame = new JFrame();
                JPanel panel = new JPanel();
                frame.setPreferredSize(new Dimension(500, 485));
                frame.setResizable(false);

                ProductoDAOImpl productoDAO = new ProductoDAOImpl();
                List<Producto> lista = new ArrayList();
                int numProductos = 0;
                try {
                    lista = productoDAO.obtenerProductos();
                    numProductos = lista.size();
                } catch (SQLException ex) {
                    Logger.getLogger(Gestor.class.getName()).log(Level.SEVERE, null, ex);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(Gestor.class.getName()).log(Level.SEVERE, null, ex);
                }

                String[] nombreColumnas = {"Nombre", "Precio", "Categoria"};
                DefaultTableModel model = new DefaultTableModel(nombreColumnas, 0);
                JTable table = new JTable(model);
                table.getTableHeader().setReorderingAllowed(false);

                for (int i = 0; i < numProductos; i++) {
                    String[] rowData = {lista.get(i).getNombre(), String.valueOf(lista.get(i).getPrecio()), lista.get(i).getCategoria()};
                    model.addRow(rowData);
                }

                table.addMouseListener(new java.awt.event.MouseAdapter() {
                    public void mouseClicked(java.awt.event.MouseEvent evt) {
                        tableMouseClicked(evt);
                    }

                    private void tableMouseClicked(MouseEvent evt) {
                        ProductoDAOImpl productoDAO = new ProductoDAOImpl();
                        int column = 0;
                        int row = table.getSelectedRow();
                        String text = table.getModel().getValueAt(row, column).toString();
                        try {
                            int confirmacio = JOptionPane.showConfirmDialog(null, "¿Quieres eliminar este producto?");
                            if (confirmacio == JOptionPane.YES_OPTION) {
                                productoDAO.eliminarProducto(text);
                                JOptionPane.showMessageDialog(null, "Producto eliminado correctamente.");
                                frame.dispose();
                                dispose();
                                new PantallaPrincipal(admin).setVisible(true);
                            }
                        } catch (SQLException ex) {
                            JOptionPane.showMessageDialog(null, "Error eliminando producto.");
                        } catch (ClassNotFoundException ex) {
                            JOptionPane.showMessageDialog(null, "Error eliminando producto.");
                        }
                    }
                });

                JScrollPane scrollPane = new JScrollPane(table);
                panel.add(scrollPane);
                frame.add(panel);

                frame.pack();
                frame.setVisible(true);

            }
        });
        //--
        menuProducto.add(menuItemInsertarProducto);
        menuProducto.add(menuItemMostrarProductos);
        menuProducto.add(menuItemModificarProducto);
        menuProducto.add(menuItemEliminarProducto);
        menuAdministrar.add(menuProducto);

        menuBar.add(menuAdministrar);
        setJMenuBar(menuBar);
    }

    // Variables declaration - do not modify                     
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanelLista;
    private javax.swing.JTabbedPane jTabbed;
    private javax.swing.JToggleButton jToggleButton1;
    private javax.swing.JToggleButton jToggleButton2;
    // End of variables declaration                         
}
