package m13_actfinal;

import java.sql.PreparedStatement;
import java.sql.SQLException;

public class LineaFacturaDAOImpl {

    public LineaFacturaDAOImpl() {
    }
    
    public void insertarProducto(LineaFactura lf) throws SQLException, ClassNotFoundException {
        // Conectar a la base de datos
        Connexio conexion = new Connexio();

        // Preparar la sentencia SQL
        String sql = "INSERT INTO Lineas_Factura (idFactura, idProducto, cantidad, precio) VALUES (?, ?, ?, ?)";
        PreparedStatement sentencia = conexion.prepararSentencia(sql);
        sentencia.setInt(1, lf.getIdFactura());
        sentencia.setInt(2, lf.getIdProducto());
        sentencia.setInt(3, lf.getCantidad());
        sentencia.setFloat(4, lf.getPrecio());

        // Ejecutar la sentencia
        sentencia.executeUpdate();

        // Cerrar la conexión a la base de datos
        conexion.cerrar();
    }
}
