package m13_actfinal;

import java.awt.Dimension;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.WindowConstants;

public class PantallaPrincipalAdmin{
    private JFrame frame;
    Gestor gestor;

    public PantallaPrincipalAdmin() {
        initComponents();
    }
    
    private void initComponents(){
        gestor = new Gestor();
        frame = new JFrame();
        frame.setPreferredSize(new Dimension(500, 400));
        frame.setResizable(false);
        
        initMenuBar();
        
        frame.pack();
        frame.setVisible(true);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }
    
    private void initMenuBar(){
        JMenuBar menuBar = new JMenuBar();
        JMenu menuAdministrar = new JMenu("Administrar");
        //-------------
        JMenu menuUsuario = new JMenu("Usuarios");
        JMenuItem menuItemInsertarUsuario = new JMenuItem("Insertar");
        menuItemInsertarUsuario.setActionCommand("InsertarUsuario");
        menuItemInsertarUsuario.addActionListener(gestor);
        //----
        JMenuItem menuItemMostrarUsuarios = new JMenuItem("Mostrar");
        menuItemMostrarUsuarios.setActionCommand("MostrarUsuario");
        menuItemMostrarUsuarios.addActionListener(gestor);
        //----
        JMenuItem menuItemEliminarUsuario = new JMenuItem("Eliminar");
        menuItemEliminarUsuario.setActionCommand("EliminarUsuario");
        menuItemEliminarUsuario.addActionListener(gestor);
        //--
        menuUsuario.add(menuItemInsertarUsuario);
        menuUsuario.add(menuItemMostrarUsuarios);
        menuUsuario.add(menuItemEliminarUsuario);
        menuAdministrar.add(menuUsuario);
        
        //-------------
        JMenu menuProducto = new JMenu("Productos");
        JMenuItem menuItemInsertarProducto = new JMenuItem("Insertar");
        menuItemInsertarProducto.setActionCommand("InsertarProducto");
        menuItemInsertarProducto.addActionListener(gestor);
        //----
        JMenuItem menuItemMostrarProductos = new JMenuItem("Mostrar");
        menuItemMostrarProductos.setActionCommand("MostrarProducto");
        menuItemMostrarProductos.addActionListener(gestor);
        //----
        JMenuItem menuItemEliminarProducto = new JMenuItem("Eliminar");
        menuItemEliminarProducto.setActionCommand("EliminarProducto");
        menuItemEliminarProducto.addActionListener(gestor);
        //--
        menuProducto.add(menuItemInsertarProducto);
        menuProducto.add(menuItemMostrarProductos);
        menuProducto.add(menuItemEliminarProducto);
        menuAdministrar.add(menuProducto);
        
        menuBar.add(menuAdministrar);
        frame.setJMenuBar(menuBar);
    }
}
