package m13_actfinal;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ProductoDAOImpl {
    
    
    public ProductoDAOImpl() {
    }
    
    public void insertarProducto(Producto p) throws SQLException, ClassNotFoundException {
        // Conectar a la base de datos
        Connexio conexion = new Connexio();

        // Preparar la sentencia SQL
        String sql = "INSERT INTO productos (nombre, precio, categoria) VALUES (?, ?, ?)";
        PreparedStatement sentencia = conexion.prepararSentencia(sql);
        sentencia.setString(1, p.getNombre());
        sentencia.setFloat(2, p.getPrecio());
        sentencia.setString(3, p.getCategoria());

        // Ejecutar la sentencia
        sentencia.executeUpdate();

        // Cerrar la conexión a la base de datos
        conexion.cerrar();
    }
    
    public void eliminarProducto(String text) throws SQLException, ClassNotFoundException {
        Connexio conexion = new Connexio();

        // Preparar la sentencia SQL
        String sql = "DELETE FROM productos WHERE nombre=?";
        PreparedStatement sentencia = conexion.prepararSentencia(sql);
        sentencia.setString(1, text);

        // Ejecutar la sentencia
        sentencia.executeUpdate();

        // Cerrar la conexión a la base de datos
        conexion.cerrar();
    }
    
    public List<Producto> obtenerProductos() throws SQLException, ClassNotFoundException{
        List<Producto> lista = new ArrayList();
        
        Connexio conexion = new Connexio();

        String sql = "SELECT nombre, precio, categoria FROM productos ORDER BY categoria, nombre";
        Statement statement = conexion.createStatement();
        ResultSet resultSet = statement.executeQuery(sql);

        // Agregar los resultados a la tabla
        while (resultSet.next()) {
            lista.add(new Producto(resultSet.getString(1), resultSet.getFloat(2), resultSet.getString(3)));
        }

        // Cerrar la conexión a MySQL
        resultSet.close();
        statement.close();
        conexion.cerrar();
        
        return lista;
    }
    
    public String[] obtenerCategoriaProductos() throws SQLException, ClassNotFoundException{
        List<String> listaTemp = new ArrayList();
        Connexio conexion = new Connexio();

        String sql = "SELECT DISTINCT(categoria) FROM productos ORDER BY categoria";
        Statement statement = conexion.createStatement();
        ResultSet resultSet = statement.executeQuery(sql);

        // Agregar los resultados a la tabla
        while (resultSet.next()) {
            listaTemp.add(resultSet.getString(1));
        }
        
        String[] lista = new String[listaTemp.size()];
        for (int i = 0; i < listaTemp.size(); i++) {
            lista[i] = listaTemp.get(i);
        }

        // Cerrar la conexión a MySQL
        resultSet.close();
        statement.close();
        conexion.cerrar();
        
        return lista;
    }
    
    
}
