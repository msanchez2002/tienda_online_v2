package m13_actfinal;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.ScrollPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Gestor implements ActionListener {

    public Gestor() {
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        switch (e.getActionCommand()) {
            case "InsertarUsuario":
                insertarUsuario();
                break;
            case "MostrarUsuario":
                mostrarUsuario();
                break;
            case "EliminarUsuario":
                eliminarUsuario();
                break;
            case "InsertarProducto":
                insertarProducto();
                break;
            case "MostrarProducto":
                mostrarProducto();
                break;
            case "EliminarProducto":
                eliminarProducto();
                break;
        }

    }

    private void insertarUsuario() {
        JFrame frame = new JFrame();
        frame.setPreferredSize(new Dimension(400, 300));
        frame.setResizable(false);

        GridBagLayout layout = new GridBagLayout();
        frame.setLayout(layout);

        JLabel nombreLabel = new JLabel("Nombre:");
        JTextField nombreField = new JTextField(20);
        JLabel contrasenaLabel = new JLabel("Contraseña:");
        JPasswordField contrasenaField = new JPasswordField(20);
        JLabel administradorLabel = new JLabel("Administrador:");
        JCheckBox administradorCheckBox = new JCheckBox();
        JButton insertarButton = new JButton("Insertar");

        insertarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String nombre = nombreField.getText();
                String contrasena = new String(contrasenaField.getPassword());
                boolean administrador = false;
                if (administradorCheckBox.isSelected()) {
                    administrador = true;
                }

                if (nombre.equals("")) {
                    JOptionPane.showMessageDialog(null, "Tienes que introducir un nombre.");
                } else if (contrasena.equals("")) {
                    JOptionPane.showMessageDialog(null, "Tienes que introducir una contraseña.");
                } else {
                    try {
                        UsuarioDAOImpl usuarioDAO = new UsuarioDAOImpl();
                        usuarioDAO.insertarUsuario(new Usuario(nombre, contrasena, administrador));
                        JOptionPane.showMessageDialog(null, "Inserción correcta.");
                        frame.dispose();
                    } catch (SQLException ex) {
                        JOptionPane.showMessageDialog(null, "El usuario ya existe.");
                    } catch (ClassNotFoundException ex) {
                        ex.printStackTrace();
                        JOptionPane.showMessageDialog(null, "Error de connexión en la base de datos");
                    }
                }
            }
        });

        GridBagConstraints constraints = new GridBagConstraints();
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.insets = new Insets(0, 0, 20, 5);
        constraints.anchor = GridBagConstraints.EAST;
        frame.add(nombreLabel, constraints);

        constraints.gridx = 1;
        frame.add(nombreField, constraints);

        constraints.gridx = 0;
        constraints.gridy = 1;
        frame.add(contrasenaLabel, constraints);

        constraints.gridx = 1;
        frame.add(contrasenaField, constraints);

        constraints.gridx = 0;
        constraints.gridy = 2;
        frame.add(administradorLabel, constraints);

        constraints.gridx = 1;
        constraints.anchor = GridBagConstraints.WEST;
        frame.add(administradorCheckBox, constraints);

        constraints.gridx = 0;
        constraints.gridy = 3;
        constraints.gridwidth = 3;
        constraints.anchor = GridBagConstraints.CENTER;
        frame.add(insertarButton, constraints);

        frame.pack();
        frame.setVisible(true);
    }

    private void mostrarUsuario() {
        JFrame frame = new JFrame();
        JPanel panel = new JPanel();
        frame.setPreferredSize(new Dimension(500, 485));
        frame.setResizable(false);

        UsuarioDAOImpl usuarioDAO = new UsuarioDAOImpl();
        List<Usuario> lista = new ArrayList();
        int numUsuarios = 0;
        try {
            lista = usuarioDAO.obtenerUsuarios();
            numUsuarios = lista.size();
        } catch (SQLException ex) {
            Logger.getLogger(Gestor.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Gestor.class.getName()).log(Level.SEVERE, null, ex);
        }

        String[] nombreColumnas = {"NomUsuari", "Administrador"};
        DefaultTableModel model = new DefaultTableModel(nombreColumnas, 0);
        JTable table = new JTable(model);
        table.getTableHeader().setReorderingAllowed(false);

        for (int i = 0; i < numUsuarios; i++) {
            if (lista.get(i).isAdministrador()) {
                String[] rowData = {lista.get(i).getNombre(), "x"};
                model.addRow(rowData);
            } else {
                String[] rowData = {lista.get(i).getNombre(), " "};
                model.addRow(rowData);
            }
        }

        table.setEnabled(false);

        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane);
        frame.add(panel);

        frame.pack();
        frame.setVisible(true);
    }

    private void eliminarUsuario() {
        JFrame frame = new JFrame();
        JPanel panel = new JPanel();
        frame.setPreferredSize(new Dimension(500, 485));
        frame.setResizable(false);

        UsuarioDAOImpl usuarioDAO = new UsuarioDAOImpl();
        List<Usuario> lista = new ArrayList();
        int numUsuarios = 0;
        try {
            lista = usuarioDAO.obtenerUsuarios();
            numUsuarios = lista.size();
        } catch (SQLException ex) {
            Logger.getLogger(Gestor.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Gestor.class.getName()).log(Level.SEVERE, null, ex);
        }

        String[] nombreColumnas = {"NomUsuari", "Administrador"};
        DefaultTableModel model = new DefaultTableModel(nombreColumnas, 0);
        JTable table = new JTable(model);
        table.getTableHeader().setReorderingAllowed(false);

        for (int i = 0; i < numUsuarios; i++) {
            if (lista.get(i).isAdministrador()) {
                String[] rowData = {lista.get(i).getNombre(), "x"};
                model.addRow(rowData);
            } else {
                String[] rowData = {lista.get(i).getNombre(), " "};
                model.addRow(rowData);
            }
        }

        table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableMouseClicked(evt);
            }

            private void tableMouseClicked(MouseEvent evt) {
                UsuarioDAOImpl usuarioDAO = new UsuarioDAOImpl();
                int column = 0;
                int row = table.getSelectedRow();
                String text = table.getModel().getValueAt(row, column).toString();
                try {
                    int confirmacio = JOptionPane.showConfirmDialog(null, "¿Quieres eliminar este usuario?");
                    if (confirmacio == JOptionPane.YES_OPTION) {
                        usuarioDAO.eliminarUsuario(text);
                        JOptionPane.showMessageDialog(null, "Usuario eliminado correctamente.");
                        frame.dispose();
                    }
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, "Error eliminando usuario.");
                } catch (ClassNotFoundException ex) {
                    JOptionPane.showMessageDialog(null, "Error eliminando usuario.");
                }
            }
        });

        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane);
        frame.add(panel);

        frame.pack();
        frame.setVisible(true);
    }

    private void insertarProducto() {
        try {
            JFrame frame = new JFrame();
            frame.setPreferredSize(new Dimension(400, 350));
            frame.setResizable(false);

            GridBagLayout layout = new GridBagLayout();
            frame.setLayout(layout);

            ProductoDAOImpl productoDAO = new ProductoDAOImpl();

            JLabel nombreLabel = new JLabel("Nombre: ");
            JTextField nombreField = new JTextField(20);
            JLabel precioLabel = new JLabel("Precio: ");
            JTextField precioField = new JTextField(20);
            JLabel categoriaLabel = new JLabel("Categoria: ");
            String[] categorias = productoDAO.obtenerCategoriaProductos();
            JComboBox<String> categoriasComboBox = new JComboBox<>(categorias);
            JLabel otraCategoriaLabel = new JLabel("Otra:");
            JCheckBox otraCategoriaCheckBox = new JCheckBox();
            JLabel categoriaNuevaLabel = new JLabel("Categoria Nueva: ");
            categoriaNuevaLabel.setVisible(false);
            JTextField categoriaNuevaField = new JTextField(20);
            categoriaNuevaField.setVisible(false);

            otraCategoriaCheckBox.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    if (otraCategoriaCheckBox.isSelected()) {
                        categoriaNuevaLabel.setVisible(true);
                        categoriaNuevaField.setVisible(true);
                    } else {
                        categoriaNuevaLabel.setVisible(false);
                        categoriaNuevaField.setVisible(false);
                    }
                }
            });

            JButton insertarButton = new JButton("Insertar");

            insertarButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {

                    try {
                        if (nombreField.getText().equals("")) {
                            JOptionPane.showMessageDialog(null, "Tienes que introducir un nombre.");
                        } else if (precioField.getText().equals("")) {
                            JOptionPane.showMessageDialog(null, "Tienes que introducir un precio.");
                        } else {

                            String nombre = nombreField.getText();
                            float precio = Float.parseFloat(precioField.getText());
                            String categoria = "";

                            if (otraCategoriaCheckBox.isSelected()) {
                                if (categoriaNuevaField.getText().equals("")) {
                                    JOptionPane.showMessageDialog(null, "Tienes que introducir una nueva categoria.");
                                } else {
                                    categoria = categoriaNuevaField.getText();
                                }
                            } else {
                                categoria = (String) categoriasComboBox.getSelectedItem();
                            }

                            if (!categoria.equals("")) {
                                ProductoDAOImpl productoDAO = new ProductoDAOImpl();
                                productoDAO.insertarProducto(new Producto(nombre, precio, categoria));
                                JOptionPane.showMessageDialog(null, "Inserción correcta.");
                                frame.dispose();
                            }

                        }
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(null, "Precio no valido.");
                    } catch (SQLException ex) {
                        JOptionPane.showMessageDialog(null, "El producto ya existe.");
                    } catch (ClassNotFoundException ex) {
                        ex.printStackTrace();
                        JOptionPane.showMessageDialog(null, "Error de connexión en la base de datos");
                    }
                }
            });

            GridBagConstraints constraints = new GridBagConstraints();
            constraints.gridx = 0;
            constraints.gridy = 0;
            constraints.insets = new Insets(0, 0, 20, 5);
            constraints.anchor = GridBagConstraints.EAST;
            frame.add(nombreLabel, constraints);

            constraints.gridx = 1;
            frame.add(nombreField, constraints);

            constraints.gridx = 0;
            constraints.gridy = 1;
            frame.add(precioLabel, constraints);

            constraints.gridx = 1;
            frame.add(precioField, constraints);

            constraints.gridx = 0;
            constraints.gridy = 2;
            frame.add(categoriaLabel, constraints);

            constraints.gridx = 1;
            constraints.anchor = GridBagConstraints.WEST;
            frame.add(categoriasComboBox, constraints);

            constraints.gridx = 0;
            constraints.gridy = 3;
            constraints.anchor = GridBagConstraints.EAST;
            frame.add(otraCategoriaLabel, constraints);

            constraints.gridx = 1;
            constraints.anchor = GridBagConstraints.WEST;
            frame.add(otraCategoriaCheckBox, constraints);

            constraints.gridx = 0;
            constraints.gridy = 4;
            frame.add(categoriaNuevaLabel, constraints);

            constraints.gridx = 1;
            frame.add(categoriaNuevaField, constraints);

            constraints.gridx = 0;
            constraints.gridy = 5;
            constraints.gridwidth = 3;
            constraints.anchor = GridBagConstraints.CENTER;
            frame.add(insertarButton, constraints);

            frame.pack();
            frame.setVisible(true);
        } catch (SQLException ex) {
            Logger.getLogger(Gestor.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Gestor.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void mostrarProducto() {
        JFrame frame = new JFrame();
        JPanel panel = new JPanel();
        frame.setPreferredSize(new Dimension(500, 485));
        frame.setResizable(false);

        ProductoDAOImpl productoDAO = new ProductoDAOImpl();
        List<Producto> lista = new ArrayList();
        int numProductos = 0;
        try {
            lista = productoDAO.obtenerProductos();
            numProductos = lista.size();
        } catch (SQLException ex) {
            Logger.getLogger(Gestor.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Gestor.class.getName()).log(Level.SEVERE, null, ex);
        }

        String[] nombreColumnas = {"Nombre", "Precio", "Categoria"};
        DefaultTableModel model = new DefaultTableModel(nombreColumnas, 0);
        JTable table = new JTable(model);
        table.getTableHeader().setReorderingAllowed(false);

        for (int i = 0; i < numProductos; i++) {
                String[] rowData = {lista.get(i).getNombre(), String.valueOf(lista.get(i).getPrecio()), lista.get(i).getCategoria()};
                model.addRow(rowData);
        }

        table.setEnabled(false);

        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane);
        frame.add(panel);

        frame.pack();
        frame.setVisible(true);
    }

    private void eliminarProducto() {
        JFrame frame = new JFrame();
        JPanel panel = new JPanel();
        frame.setPreferredSize(new Dimension(500, 485));
        frame.setResizable(false);

        ProductoDAOImpl productoDAO = new ProductoDAOImpl();
        List<Producto> lista = new ArrayList();
        int numProductos = 0;
        try {
            lista = productoDAO.obtenerProductos();
            numProductos = lista.size();
        } catch (SQLException ex) {
            Logger.getLogger(Gestor.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Gestor.class.getName()).log(Level.SEVERE, null, ex);
        }

        String[] nombreColumnas = {"Nombre", "Precio", "Categoria"};
        DefaultTableModel model = new DefaultTableModel(nombreColumnas, 0);
        JTable table = new JTable(model);
        table.getTableHeader().setReorderingAllowed(false);

        for (int i = 0; i < numProductos; i++) {
                String[] rowData = {lista.get(i).getNombre(), String.valueOf(lista.get(i).getPrecio()), lista.get(i).getCategoria()};
                model.addRow(rowData);
        }

        table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableMouseClicked(evt);
            }

            private void tableMouseClicked(MouseEvent evt) {
                ProductoDAOImpl productoDAO = new ProductoDAOImpl();
                int column = 0;
                int row = table.getSelectedRow();
                String text = table.getModel().getValueAt(row, column).toString();
                try {
                    int confirmacio = JOptionPane.showConfirmDialog(null, "¿Quieres eliminar este producto?");
                    if (confirmacio == JOptionPane.YES_OPTION) {
                        productoDAO.eliminarProducto(text);
                        JOptionPane.showMessageDialog(null, "Producto eliminado correctamente.");
                        frame.dispose();
                    }
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, "Error eliminando producto.");
                } catch (ClassNotFoundException ex) {
                    JOptionPane.showMessageDialog(null, "Error eliminando producto.");
                }
            }
        });

        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane);
        frame.add(panel);

        frame.pack();
        frame.setVisible(true);
    }

}
