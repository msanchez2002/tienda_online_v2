package m13_actfinal;

import java.awt.Dimension;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

public class LoginPantalla {

    public LoginPantalla() {
        initComponents();
    }

    private void initComponents() {

        JFrame frame = new JFrame();
        frame.setPreferredSize(new Dimension(400, 300));
        frame.setResizable(false);

        GridBagLayout layout = new GridBagLayout();
        frame.setLayout(layout);

        JLabel nomLabel = new JLabel("Nom: ");
        JTextField nomField = new JTextField(15);
        JLabel contrasenaLabel = new JLabel("Contrassenya: ");
        JPasswordField contrasenaField = new JPasswordField(15);
        JButton registrarButton = new JButton("Iniciar Sesión");

        registrarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String nombre = nomField.getText();
                String contrasena = new String(contrasenaField.getPassword());
                UsuarioDAOImpl usuarioDAO = new UsuarioDAOImpl();
                Usuario usuario = new Usuario(nombre, contrasena);
                try {
                    if (usuarioDAO.comprobarUsuario(usuario)) {
                        Usuario usuarioTemp = usuarioDAO.obtenerUsuario(usuario);
                        if (usuarioTemp.isAdministrador()) {
                            frame.dispose();
                            new PantallaPrincipalAdmin();
                        } else {
                            System.out.println("NO ES ADMIN");
                        }
                    } else {
                        JOptionPane.showMessageDialog(new Frame(), "Usuario o contraseña incorrecto.");
                    }
                } catch (SQLException ex) {
                    Logger.getLogger(LoginPantalla.class.getName()).log(Level.SEVERE, null, ex);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(LoginPantalla.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });

        GridBagConstraints constraints = new GridBagConstraints();
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.insets = new Insets(0, 0, 25, 5);
        constraints.anchor = GridBagConstraints.EAST;
        frame.add(nomLabel, constraints);

        constraints.gridx = 1;
        frame.add(nomField, constraints);

        constraints.gridx = 0;
        constraints.gridy = 1;
        frame.add(contrasenaLabel, constraints);

        constraints.gridx = 1;
        frame.add(contrasenaField, constraints);

        constraints.gridx = 0;
        constraints.gridy = 2;
        constraints.gridwidth = 2;
        constraints.anchor = GridBagConstraints.CENTER;
        frame.add(registrarButton, constraints);

        frame.pack();
        frame.setVisible(true);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }
}
