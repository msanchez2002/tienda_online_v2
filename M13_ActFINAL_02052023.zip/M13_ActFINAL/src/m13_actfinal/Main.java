package m13_actfinal;
public class Main {
    public static void main(String[] args) {
        new PantallaLogin().setVisible(true);
    }
    
}
