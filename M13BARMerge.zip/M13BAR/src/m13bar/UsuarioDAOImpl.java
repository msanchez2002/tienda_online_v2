package m13bar;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UsuarioDAOImpl {

    public UsuarioDAOImpl() {
    }
    
    public void insertarUsuario(Usuario u) throws SQLException, ClassNotFoundException {
        // Conectar a la base de datos
        Connexio conexion = new Connexio();

        // Preparar la sentencia SQL
        String sql = "INSERT INTO usuarios (nombre, contrasena) VALUES (?, MD5(?), ?)";
        PreparedStatement sentencia = conexion.prepararSentencia(sql);
        sentencia.setString(1, u.getNombre());
        sentencia.setString(2, u.getContrasena());
        sentencia.setBoolean(3, u.isAdministrador());

        // Ejecutar la sentencia
        sentencia.executeUpdate();

        // Cerrar la conexión a la base de datos
        conexion.cerrar();
    }
    
    public boolean comprobarUsuario(Usuario u) throws SQLException, ClassNotFoundException {
        Connexio conexion = new Connexio();
        boolean existe = false;

        String sql = "SELECT * FROM usuarios WHERE nombre=? AND contrasena=MD5(?)";
        PreparedStatement sentencia = conexion.prepararSentencia(sql);
        sentencia.setString(1, u.getNombre());
        sentencia.setString(2, u.getContrasena());
        ResultSet resultSet = sentencia.executeQuery();

        // Agregar los resultados a la tabla
        if (resultSet.next()) {
            existe = true;
        }

        // Cerrar la conexión a MySQL
        resultSet.close();
        sentencia.close();
        conexion.cerrar();

        return existe;
    }
    
    public Usuario obtenerUsuario(Usuario u) throws SQLException, ClassNotFoundException {
        Connexio conexion = new Connexio();
        Usuario usuario = null;

        String sql = "SELECT nombre, contrasena, administrador FROM usuarios WHERE nombre=? AND contrasena=MD5(?)";
        PreparedStatement sentencia = conexion.prepararSentencia(sql);
        sentencia.setString(1, u.getNombre());
        sentencia.setString(2, u.getContrasena());
        ResultSet resultSet = sentencia.executeQuery();

        // Agregar los resultados a la tabla
        if (resultSet.next()) {
            if (resultSet.getInt(3) == 1) {
                usuario = new Usuario(resultSet.getString(1), u.getContrasena(), true);
            }else {
                usuario = new Usuario(resultSet.getString(1), u.getContrasena(), false);
            }
            
        }

        // Cerrar la conexión a MySQL
        resultSet.close();
        sentencia.close();
        conexion.cerrar();

        return usuario;
    }
}
