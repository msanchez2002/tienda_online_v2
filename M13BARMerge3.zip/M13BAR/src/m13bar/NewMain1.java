/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package m13bar;

import java.util.ArrayList;
import java.util.regex.Pattern;

/**
 *
 * @author Alex
 */
public class NewMain1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<String> elements = new ArrayList();
        Pattern patternProducto = Pattern.compile("(.+\\sx[0-9]+)");
        final String nombreProducto1 = "Patatas";
        int num = 1;
        
        elements.add("Patatas");
        elements.add("Chocolate");

        //System.out.println("elemento1 x2".matches(".+"+"\\sx"+"[0-9]+"));
        while(num <= 5) {
        if (elements.get(0).contains(nombreProducto1)) {
            System.out.println("HERE!");
            System.out.println(elements.get(0));
            elements.set(0, nombreProducto1+" x" + num);
            System.out.println("COUNTER: "+num);
            num++;
        }
        }
        System.out.println("");
        System.out.println(elements.get(0));
        //System.out.println("Producto x23".matches("(.+\\sx[0-9]+)"));
        
    }
    
}
