<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use App\Entity\Perro;

class PerroPerfilController extends AbstractController {

    public function conectarBBDD($id) {
        $hostname = 'mariadb';
        $nombreUsuario = 'user';
        $contraseña = '';
        $nombreBaseDatos = 'mariadb_db';
        
        $nombreConexion = mysqli_connect($hostname, $nombreUsuario, $contraseña);
        mysqli_select_db($nombreConexion, $nombreBaseDatos);
        $sql = "SELECT * FROM Perros WHERE id = ".$id;
        $result = mysqli_query($nombreConexion, $sql);

        $extraido = mysqli_fetch_array($result);
        $perro = new Perro($extraido['Nombre'], $extraido['Edad'],
                $extraido['Raza'], $extraido['Descripcion'], $extraido['Precio'],
                $extraido['Descuento']);

        mysqli_free_result($result);
        mysqli_close($nombreConexion);
        
        return $perro;
        
    }

    #[Route('/perros/perro1', name: 'app_perro1')]
    public function mostrarPerro1(): Response {

        $id = 1;
        $perro = $this->conectarBBDD($id);

        return $this->render('perros/perro_perfil/index.html.twig', [
                    'perro' => $perro,
                    'id' => $id,
        ]);
    }

    #[Route('/perros/perro2', name: 'app_perro2')]
    public function mostrarPerro2(): Response {

        $id = 2;
        $perro = $this->conectarBBDD($id);

        return $this->render('perros/perro_perfil/index.html.twig', [
                    'perro' => $perro,
                    'id' => $id,
        ]);
    }

    #[Route('/perros/perro3', name: 'app_perro3')]
    public function mostrarPerro3(): Response {

        $id = 3;
        $perro = $this->conectarBBDD($id);

        return $this->render('perros/perro_perfil/index.html.twig', [
                    'perro' => $perro,
                    'id' => $id,
        ]);
    }

    #[Route('/perros/perro4', name: 'app_perro4')]
    public function mostrarPerro4(): Response {

        $id = 4;
        $perro = $this->conectarBBDD($id);

        return $this->render('perros/perro_perfil/index.html.twig', [
                    'perro' => $perro,
                    'id' => $id,
        ]);
    }

}
