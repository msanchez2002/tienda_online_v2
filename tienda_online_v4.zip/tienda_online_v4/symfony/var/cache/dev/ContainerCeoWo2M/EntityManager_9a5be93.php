<?php

namespace ContainerCeoWo2M;
include_once \dirname(__DIR__, 4).'/vendor/doctrine/persistence/src/Persistence/ObjectManager.php';
include_once \dirname(__DIR__, 4).'/vendor/doctrine/orm/lib/Doctrine/ORM/EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).'/vendor/doctrine/orm/lib/Doctrine/ORM/EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{
    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHoldera7dae = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializerb8e02 = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicProperties196d0 = [
        
    ];

    public function getConnection()
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, 'getConnection', array(), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        return $this->valueHoldera7dae->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, 'getMetadataFactory', array(), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        return $this->valueHoldera7dae->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, 'getExpressionBuilder', array(), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        return $this->valueHoldera7dae->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, 'beginTransaction', array(), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        return $this->valueHoldera7dae->beginTransaction();
    }

    public function getCache()
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, 'getCache', array(), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        return $this->valueHoldera7dae->getCache();
    }

    public function transactional($func)
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, 'transactional', array('func' => $func), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        return $this->valueHoldera7dae->transactional($func);
    }

    public function wrapInTransaction(callable $func)
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, 'wrapInTransaction', array('func' => $func), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        return $this->valueHoldera7dae->wrapInTransaction($func);
    }

    public function commit()
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, 'commit', array(), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        return $this->valueHoldera7dae->commit();
    }

    public function rollback()
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, 'rollback', array(), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        return $this->valueHoldera7dae->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, 'getClassMetadata', array('className' => $className), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        return $this->valueHoldera7dae->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, 'createQuery', array('dql' => $dql), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        return $this->valueHoldera7dae->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, 'createNamedQuery', array('name' => $name), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        return $this->valueHoldera7dae->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        return $this->valueHoldera7dae->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        return $this->valueHoldera7dae->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, 'createQueryBuilder', array(), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        return $this->valueHoldera7dae->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, 'flush', array('entity' => $entity), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        return $this->valueHoldera7dae->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        return $this->valueHoldera7dae->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        return $this->valueHoldera7dae->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        return $this->valueHoldera7dae->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, 'clear', array('entityName' => $entityName), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        return $this->valueHoldera7dae->clear($entityName);
    }

    public function close()
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, 'close', array(), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        return $this->valueHoldera7dae->close();
    }

    public function persist($entity)
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, 'persist', array('entity' => $entity), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        return $this->valueHoldera7dae->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, 'remove', array('entity' => $entity), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        return $this->valueHoldera7dae->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, 'refresh', array('entity' => $entity), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        return $this->valueHoldera7dae->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, 'detach', array('entity' => $entity), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        return $this->valueHoldera7dae->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, 'merge', array('entity' => $entity), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        return $this->valueHoldera7dae->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        return $this->valueHoldera7dae->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        return $this->valueHoldera7dae->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, 'getRepository', array('entityName' => $entityName), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        return $this->valueHoldera7dae->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, 'contains', array('entity' => $entity), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        return $this->valueHoldera7dae->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, 'getEventManager', array(), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        return $this->valueHoldera7dae->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, 'getConfiguration', array(), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        return $this->valueHoldera7dae->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, 'isOpen', array(), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        return $this->valueHoldera7dae->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, 'getUnitOfWork', array(), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        return $this->valueHoldera7dae->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        return $this->valueHoldera7dae->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        return $this->valueHoldera7dae->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, 'getProxyFactory', array(), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        return $this->valueHoldera7dae->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, 'initializeObject', array('obj' => $obj), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        return $this->valueHoldera7dae->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, 'getFilters', array(), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        return $this->valueHoldera7dae->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, 'isFiltersStateClean', array(), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        return $this->valueHoldera7dae->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, 'hasFilters', array(), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        return $this->valueHoldera7dae->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializerb8e02 = $initializer;

        return $instance;
    }

    public function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config)
    {
        static $reflection;

        if (! $this->valueHoldera7dae) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHoldera7dae = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHoldera7dae->__construct($conn, $config);
    }

    public function & __get($name)
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, '__get', ['name' => $name], $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        if (isset(self::$publicProperties196d0[$name])) {
            return $this->valueHoldera7dae->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHoldera7dae;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHoldera7dae;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, '__set', array('name' => $name, 'value' => $value), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHoldera7dae;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHoldera7dae;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, '__isset', array('name' => $name), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHoldera7dae;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHoldera7dae;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, '__unset', array('name' => $name), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHoldera7dae;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHoldera7dae;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, '__clone', array(), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        $this->valueHoldera7dae = clone $this->valueHoldera7dae;
    }

    public function __sleep()
    {
        $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, '__sleep', array(), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;

        return array('valueHoldera7dae');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializerb8e02 = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializerb8e02;
    }

    public function initializeProxy() : bool
    {
        return $this->initializerb8e02 && ($this->initializerb8e02->__invoke($valueHoldera7dae, $this, 'initializeProxy', array(), $this->initializerb8e02) || 1) && $this->valueHoldera7dae = $valueHoldera7dae;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHoldera7dae;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHoldera7dae;
    }
}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
