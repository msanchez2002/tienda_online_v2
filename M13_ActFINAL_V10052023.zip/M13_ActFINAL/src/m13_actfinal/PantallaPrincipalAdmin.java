package m13_actfinal;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;

public class PantallaPrincipalAdmin extends javax.swing.JFrame {
    
    Gestor gestor;

    static private DefaultListModel<String> modeloLista;

    static HashMap<String, Integer> numElementos = new HashMap<>();

    static int numActual = 0;

    static List<Producto> productosList;

    static double precioSinIVA = 0;

    static JLabel labelPrecioSinIVA = new JLabel("Label 1");
    static JLabel labelPrecioIVA = new JLabel("Label 2");
    static JLabel labelPrecioTotal = new JLabel("Label 3");

    static String nombreProductoBorrado;
    static int numProducto;

    static void add(JTabbedPane tabbedPane, String label) {
        int count = tabbedPane.getTabCount();
        JPanel panel = new JPanel(new GridLayout(0, 2));

        for (int i = 0; i < productosList.size(); i++) {
            if (label.equals(productosList.get(i).getCategoria())) {
                JButton button = new JButton(productosList.get(i).getNombre());
                button.addMouseListener(createMouseAdapter());
                panel.add(button);
            }
        }
        tabbedPane.addTab(label, panel);
    }

    public PantallaPrincipalAdmin() {
        initComponents();
        initMenuBar();
        actualizarPrecio();
        modeloLista = new DefaultListModel<>();
        jPanelLista.setPreferredSize(new Dimension(250, 300));

        try {
            Connexio conn = new Connexio();

            String query = "SELECT * FROM productos";

            productosList = new ArrayList();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            while (rs.next()) {
                productosList.add(new Producto(rs.getString("nombre"), rs.getFloat("Precio"),
                        rs.getString("categoria")));
            }

            Set<String> set = categorias(productosList);

            List<String> categoriaList = set.stream().collect(Collectors.toList());

            for (int i = 0; i < categoriaList.size(); i++) {
                add(jTabbed, categoriaList.get(i));
            }

            JPanel panel = new JPanel(new GridLayout(0, 2));

            conn.cerrar();

        } catch (SQLException ex) {
            ex.printStackTrace();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(PantallaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        }

        JList<String> lista = new JList<String>(modeloLista);

        JButton botonEliminar = new JButton("Eliminar");
        botonEliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int indiceSeleccionado = lista.getSelectedIndex();
                if (indiceSeleccionado >= 0) {
                    try {
                        ProductoDAOImpl productoDAO = new ProductoDAOImpl();
                        String elementoSeleccionado = modeloLista.getElementAt(indiceSeleccionado);

                        String[] bebida = modeloLista.get(indiceSeleccionado).split(" x");
                        nombreProductoBorrado = bebida[0];
                        numProducto = numElementos.get(nombreProductoBorrado);

                        float precio = productoDAO.precioProducto(nombreProductoBorrado);
                        precioSinIVA -= (precio*numProducto);
                        actualizarPrecio();

                        numElementos.remove(elementoSeleccionado);
                        modeloLista.removeElementAt(indiceSeleccionado);
                        precio = 0;
                    } catch (SQLException ex) {
                        Logger.getLogger(PantallaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (ClassNotFoundException ex) {
                        Logger.getLogger(PantallaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        });
        JButton botonEliminarTodo = new JButton("Eliminar Todo");
        botonEliminarTodo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                numElementos.clear();
                modeloLista.removeAllElements();
                precioSinIVA = 0;
                actualizarPrecio();
            }
        });
        
        
        jPanelLista.setLayout(new BorderLayout());
        jPanelLista.add(new JScrollPane(lista), BorderLayout.CENTER);
        JPanel panelSur = new JPanel(new GridLayout(2, 1));
        panelSur.add(botonEliminar);
        panelSur.add(botonEliminarTodo);
        jPanelLista.add(panelSur, BorderLayout.SOUTH);

        jPanel3.setLayout(new BorderLayout());
        jPanel3.add(labelPrecioSinIVA, BorderLayout.NORTH);
        jPanel3.add(labelPrecioIVA, BorderLayout.CENTER);
        jPanel3.add(labelPrecioTotal, BorderLayout.SOUTH);

        this.getContentPane().setPreferredSize(new Dimension(600, 400));
        this.pack();

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {
        
        gestor = new Gestor();

        jPanelLista = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jToggleButton1 = new javax.swing.JToggleButton();
        jToggleButton2 = new javax.swing.JToggleButton();
        jTabbed = new javax.swing.JTabbedPane();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout jPanelListaLayout = new javax.swing.GroupLayout(jPanelLista);
        jPanelLista.setLayout(jPanelListaLayout);
        jPanelListaLayout.setHorizontalGroup(
                jPanelListaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanelListaLayout.setVerticalGroup(
                jPanelListaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 177, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
                jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 246, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
                jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 95, Short.MAX_VALUE)
        );

        jToggleButton1.setText("Pagar");
        jToggleButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                System.out.println("A pagar");
            }
        });

        jToggleButton2.setText("Cancelar");
        jToggleButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dispose();
                new LoginPantalla();
            }
        });

        jTabbed.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                                .addGap(10, 10, 10)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                        .addComponent(jPanelLista, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                        .addGroup(layout.createSequentialGroup()
                                                .addGap(2, 2, 2)
                                                .addComponent(jToggleButton1)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jToggleButton2)))
                                .addGap(18, 18, 18)
                                .addComponent(jTabbed, javax.swing.GroupLayout.DEFAULT_SIZE, 190, Short.MAX_VALUE)
                                .addContainerGap())
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jTabbed)
                                        .addGroup(layout.createSequentialGroup()
                                                .addComponent(jPanelLista, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 26, Short.MAX_VALUE)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                        .addComponent(jToggleButton1)
                                                        .addComponent(jToggleButton2))))
                                .addContainerGap())
        );

        pack();
    }

    public Set<String> categorias(final List<Producto> productos) {
        Set<String> categorias = new HashSet<>();
        for (final Producto producto : productos) {
            categorias.add(producto.getCategoria());
        }
        return categorias;
    }

    static public MouseAdapter createMouseAdapter() {
        return new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                ProductoDAOImpl productoDAO = new ProductoDAOImpl();
                JButton boton = (JButton) e.getSource();
                String nombreElemento = boton.getText();
                int sizeNombre = nombreElemento.length();
                if (modeloLista.size() == 0) {
                    try {
                        float precio = productoDAO.precioProducto(nombreElemento);
                        String texto = nombreElemento + " x1" + " - " + precio;
                        precioSinIVA += precio;
                        actualizarPrecio();
                        modeloLista.addElement(texto);
                        numElementos.put(nombreElemento, 1);
                    } catch (SQLException ex) {
                        Logger.getLogger(PantallaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (ClassNotFoundException ex) {
                        Logger.getLogger(PantallaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                    }
                } else {
                    boolean encontrado = false;
                    for (int i = 0; i < modeloLista.size(); i++) {
                        if (modeloLista.get(i).length() >= sizeNombre) {
                            if (modeloLista.get(i).substring(0, sizeNombre).equals(nombreElemento)) {
                                encontrado = true;
                                int indice = -1;
                                for (int j = 0; j < modeloLista.size(); j++) {
                                    if (modeloLista.get(j).startsWith(nombreElemento)) {
                                        indice = j;
                                        break;
                                    }
                                }
                                if (indice == -1) {
                                    System.out.println("No existe");
                                } else {
                                    int numActual = 1;
                                    if (numElementos.containsKey(nombreElemento)) {
                                        numActual = numElementos.get(nombreElemento);
                                        numActual++;
                                    }

                                    try {
                                        float precio = productoDAO.precioProducto(nombreElemento);
                                        DecimalFormat df = new DecimalFormat("0.00");
                                        numElementos.put(nombreElemento, numActual);
                                        String formattedNumber = df.format(precio * numActual);
                                        String elementoActualizado = nombreElemento + " x" + numActual + " - " + precio + " - " + formattedNumber;
                                        precioSinIVA += precio;
                                        actualizarPrecio();
                                        modeloLista.setElementAt(elementoActualizado, indice);
                                    } catch (SQLException ex) {
                                        Logger.getLogger(PantallaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                                    } catch (ClassNotFoundException ex) {
                                        Logger.getLogger(PantallaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                                    }
                                }
                            }
                        }
                        if (encontrado) {
                            break;
                        }
                    }
                    if (!encontrado) {
                        try {
                            float precio = productoDAO.precioProducto(nombreElemento);
                            String texto = nombreElemento + " x1" + " - " + precio;
                            precioSinIVA += precio;
                            actualizarPrecio();
                            modeloLista.addElement(texto);
                            numElementos.put(nombreElemento, 1);
                        } catch (SQLException ex) {
                            Logger.getLogger(PantallaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                        } catch (ClassNotFoundException ex) {
                            Logger.getLogger(PantallaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                }
            }

        };

    }

    static public void actualizarPrecio() {
        DecimalFormat df = new DecimalFormat("0.00");
        String formattedNumber = df.format(precioSinIVA);
        labelPrecioSinIVA.setText("Precio: " + formattedNumber);
        double precioIVA = precioSinIVA * 0.21;
        formattedNumber = df.format(precioIVA);
        labelPrecioIVA.setText("IVA (21%): " + formattedNumber);
        double precioTotal = precioSinIVA + precioIVA;
        formattedNumber = df.format(precioTotal);
        labelPrecioTotal.setText("Precio Total: " + formattedNumber);
    }
    
    private void initMenuBar(){
        JMenuBar menuBar = new JMenuBar();
        JMenu menuAdministrar = new JMenu("Administrar");
        //-------------
        JMenu menuUsuario = new JMenu("Usuarios");
        JMenuItem menuItemInsertarUsuario = new JMenuItem("Insertar");
        menuItemInsertarUsuario.setActionCommand("InsertarUsuario");
        menuItemInsertarUsuario.addActionListener(gestor);
        //----
        JMenuItem menuItemMostrarUsuarios = new JMenuItem("Mostrar");
        menuItemMostrarUsuarios.setActionCommand("MostrarUsuario");
        menuItemMostrarUsuarios.addActionListener(gestor);
        //----
        JMenuItem menuItemEliminarUsuario = new JMenuItem("Eliminar");
        menuItemEliminarUsuario.setActionCommand("EliminarUsuario");
        menuItemEliminarUsuario.addActionListener(gestor);
        //--
        menuUsuario.add(menuItemInsertarUsuario);
        menuUsuario.add(menuItemMostrarUsuarios);
        menuUsuario.add(menuItemEliminarUsuario);
        menuAdministrar.add(menuUsuario);
        
        //-------------
        JMenu menuProducto = new JMenu("Productos");
        JMenuItem menuItemInsertarProducto = new JMenuItem("Insertar");
        menuItemInsertarProducto.setActionCommand("InsertarProducto");
        menuItemInsertarProducto.addActionListener(gestor);
        //----
        JMenuItem menuItemMostrarProductos = new JMenuItem("Mostrar");
        menuItemMostrarProductos.setActionCommand("MostrarProducto");
        menuItemMostrarProductos.addActionListener(gestor);
        //----
        JMenuItem menuItemEliminarProducto = new JMenuItem("Eliminar");
        menuItemEliminarProducto.setActionCommand("EliminarProducto");
        menuItemEliminarProducto.addActionListener(gestor);
        //--
        menuProducto.add(menuItemInsertarProducto);
        menuProducto.add(menuItemMostrarProductos);
        menuProducto.add(menuItemEliminarProducto);
        menuAdministrar.add(menuProducto);
        
        menuBar.add(menuAdministrar);
        setJMenuBar(menuBar);
    }

    // Variables declaration - do not modify                     
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanelLista;
    private javax.swing.JTabbedPane jTabbed;
    private javax.swing.JToggleButton jToggleButton1;
    private javax.swing.JToggleButton jToggleButton2;
    // End of variables declaration                         
}
