<?php
namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use App\Entity\Perro;

class PerroPerfilController1 extends AbstractController {

    #[Route('/perros/perro1', name: 'app_perro1')]
    public function mostrar(): Response{
        
        $number = random_int(0, 15);

        return $this->render('perros/perro1/index.html.twig', [
            'number' => $number,
        ]);
    }
}