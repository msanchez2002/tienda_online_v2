<?php

namespace App\Controller;
 
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
 
class IniciController extends AbstractController {

    #[Route('/inici', name: 'app_inici')]
    public function index(): Response {
      $hostname = 'mariadb';
      $nombreUsuario = 'user';
      $contraseña = '';
      $nombreBaseDatos = 'mariadb_db';

      $nombreConexion = mysqli_connect($hostname , $nombreUsuario , $contraseña);
      mysqli_select_db($nombreConexion, $nombreBaseDatos);
      $result = mysqli_query($nombreConexion, "SELECT * FROM Persona");

      $numPersonas = $result->num_rows;
      $arrayPersonas = array();
      for ($i=0; $i < $numPersonas; $i++) {
        mysqli_data_seek ($result, $i);
        $extraido= mysqli_fetch_array($result);
        
        $arrayPersonas[] = new Persona($extraido['Nombre'], $extraido['Edad']);
        
      }
      
      mysqli_free_result($result);
      mysqli_close($nombreConexion);

        return $this->render('inici/index.html.twig', [
            'ArrayPersonas' => $arrayPersonas,
        ]);
    }
}
