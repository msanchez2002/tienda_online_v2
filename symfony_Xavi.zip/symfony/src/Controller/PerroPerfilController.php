<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use App\Entity\Perro;

class PerroPerfilController extends AbstractController {

    public function conectarBBDD($id) {
        $hostname = 'mariadb';
        $nombreUsuario = 'user';
        $contraseña = '';
        $nombreBaseDatos = 'mariadb_db';
        
        $nombreConexion = mysqli_connect($hostname, $nombreUsuario, $contraseña);
        mysqli_select_db($nombreConexion, $nombreBaseDatos);
        $sql = "SELECT * FROM Perros WHERE id = ".$id;
        $result = mysqli_query($nombreConexion, $sql);

        $extraido = mysqli_fetch_array($result);
        $perro = new Perro($extraido['id'], $extraido['Nombre'], $extraido['Edad'],
                $extraido['Raza'], $extraido['Descripcion'], $extraido['Precio'],
                $extraido['Descuento'], $extraido['NoVendido']);

        mysqli_free_result($result);
        mysqli_close($nombreConexion);
        
        

        return $perro;
        
    }

    
    

    #[Route('/perros/perro1', name: 'app_perro1')]
    public function mostrarPerro1(Request $request): Response {

        $session = $request->getSession();
        $nom = $session->get('name');
        $id = 1;
        $perro = $this->conectarBBDD($id);

        $informacion1 = 'información a enviar';
        return $this->render('perros/perro_perfil/index.html.twig', [
                    'perro' => $perro,
                    'informacion1' => $informacion1
        ]);
    }

    #[Route('/perros/perro2', name: 'app_perro2')]
    public function mostrarPerro2(Request $request): Response {

        $session = $request->getSession();
        $nom = $session->get('name');
        $id = 2;
        $perro = $this->conectarBBDD($id);

        $informacion2 = 'información a enviar';
        return $this->render('perros/perro_perfil/index.html.twig', [
                    'perro' => $perro,
                    'informacion2' => $informacion2
        ]);
    }

    #[Route('/perros/perro3', name: 'app_perro3')]
    public function mostrarPerro3(Request $request): Response {

        $session = $request->getSession();
        $nom = $session->get('name');
        $id = 3;
        $perro = $this->conectarBBDD($id);

        $informacion3 = 'información a enviar';
        return $this->render('perros/perro_perfil/index.html.twig', [
                    'perro' => $perro,
                    'informacion3' => $informacion3
        ]);
    }

    #[Route('/perros/perro4', name: 'app_perro4')]
    public function mostrarPerro4(Request $request): Response {

        $session = $request->getSession();
        $nom = $session->get('name');
        $id = 4;
        $perro = $this->conectarBBDD($id);

        $informacion4 = 'información a enviar';
        return $this->render('perros/perro_perfil/index.html.twig', [
                    'perro' => $perro,
                    'informacion4' => $informacion4
        ]);
    }


    #[Route('/perros/perro5', name: 'app_perro5')]
    public function mostrarPerro5(Request $request): Response {

        $session = $request->getSession();
        $nom = $session->get('name');
        $id = 5;
        $perro = $this->conectarBBDD($id);

        $informacion5 = 'información a enviar';
        return $this->render('perros/perro_perfil/index.html.twig', [
                    'perro' => $perro,
                    'informacion5' => $informacion5

        ]);
    }
}
