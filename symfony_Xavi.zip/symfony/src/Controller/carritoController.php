<?php

namespace App\Controller;
 
use App\Entity\Perro;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;



class carritoController extends AbstractController {

    #[Route('/carrito', name: 'app_carrito')]
    public function index(Request $request): Response {

        $session = $request->getSession();
        $nom = $session->get('name');
      

      $hostname = 'mariadb';
      $nombreUsuario = 'user';
      $contraseña = '';
      $nombreBaseDatos = 'mariadb_db';

      $nombreConexion = mysqli_connect($hostname , $nombreUsuario , $contraseña);
      mysqli_select_db($nombreConexion, $nombreBaseDatos);
      $result = mysqli_query($nombreConexion, "SELECT * FROM Perros WHERE NoVendido = 1 LIMIT 2");

      $numPerros = $result->num_rows;
      $arrayPerros = array();
      for ($i=0; $i < $numPerros; $i++) {
        mysqli_data_seek ($result, $i);
        $extraido= mysqli_fetch_array($result);
        
        $arrayPerros[] = new Perro($extraido['id'], $extraido['Nombre'], $extraido['Edad'],
        $extraido['Raza'], $extraido['Descripcion'], $extraido['Precio'],
        $extraido['Descuento'], $extraido['NoVendido']);
        
      }
      
      mysqli_free_result($result);
      mysqli_close($nombreConexion);



      //$informacion = $_POST['informacion'];



        return $this->render('carrito/carrito.html.twig', [
            'ArrayPerros' => $arrayPerros,
        ]);
    }





}
