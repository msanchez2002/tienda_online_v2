<?php

namespace App\Controller;
 
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use App\Entity\Perro;
 
class PerroController extends AbstractController {

    #[Route('/perros', name: 'app_perro')]
    public function index(): Response {
      $hostname = 'mariadb';
      $nombreUsuario = 'user';
      $contraseña = '';
      $nombreBaseDatos = 'mariadb_db';

      $nombreConexion = mysqli_connect($hostname , $nombreUsuario , $contraseña);
      mysqli_select_db($nombreConexion, $nombreBaseDatos);

      $result = mysqli_query($nombreConexion, "SELECT * FROM Perros");
      $num = $result->num_rows;
      $arrayPerros = array();
      for ($i=0; $i < $num; $i++) {
        mysqli_data_seek ($result, $i);
        $extraido= mysqli_fetch_array($result);
        $arrayPerros[] = new Perro($extraido['id'], $extraido['Nombre'], $extraido['Edad'],
                $extraido['Raza'], $extraido['Descripcion'], $extraido['Precio'],
                $extraido['Descuento'], $extraido['NoVendido']);
        
      }

      $result = mysqli_query($nombreConexion, "SELECT DISTINCT(Raza) FROM Perros");
      $num = $result->num_rows;
      $arrayRazas = array();
      for ($i=0; $i < $num; $i++) {
        mysqli_data_seek ($result, $i);
        $extraido= mysqli_fetch_array($result);
        $arrayRazas[] = $extraido['Raza'];
      }
      
      mysqli_free_result($result);
      mysqli_close($nombreConexion);

        return $this->render('perros/index.html.twig', [
            'ArrayPerros' => $arrayPerros,
            'ArrayRazas' => $arrayRazas,
        ]);
    }
}
