<?php
// src/Controller/LuckyController.php
namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class CompraController extends AbstractController{

    #[Route('/compra', name: 'app_compra')]
    public function Compra(): Response{
        
        $number = random_int(0, 15);

        return $this->render('compra/index.html.twig', [
            'number' => $number,
        ]);
    }
}