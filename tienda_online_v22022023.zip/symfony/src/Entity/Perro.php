<?php

namespace App\Entity;

class Perro {
    
    private int $id;
    private string $nombre;
    private int $edad;
    private string $raza;
    private string $descripcion;
    private float $precio;
    private float $descuento;
    private int $noVendido;
    
    public function __construct(int $id, string $nombre, int $edad, string $raza, string $descripcion, float $precio, float $descuento, int $noVendido) {
        $this->id = $id;
        $this->nombre = $nombre;
        $this->edad = $edad;
        $this->raza = $raza;
        $this->descripcion = $descripcion;
        $this->precio = $precio;
        $this->descuento = $descuento;
        $this->noVendido = $noVendido;
    }
    
    public function getNombre(): string {
        return $this->nombre;
    }

    public function getEdad(): int {
        return $this->edad;
    }

    public function getRaza(): string {
        return $this->raza;
    }

    public function getDescripcion(): string {
        return $this->descripcion;
    }

    public function getPrecio(): float {
        return $this->precio;
    }

    public function getDescuento(): float {
        return $this->descuento;
    }

    public function setNombre(string $nombre): void {
        $this->nombre = $nombre;
    }

    public function setEdad(int $edad): void {
        $this->edad = $edad;
    }

    public function setRaza(string $raza): void {
        $this->raza = $raza;
    }

    public function setDescripcion(string $descripcion): void {
        $this->descripcion = $descripcion;
    }

    public function setPrecio(float $precio): void {
        $this->precio = $precio;
    }

    public function setDescuento(float $descuento): void {
        $this->descuento = $descuento;
    }
    
    public function getNoVendido(): int {
        return $this->noVendido;
    }

    public function setNoVendido(int $noVendido): void {
        $this->noVendido = $noVendido;
    }
    
    public function getId(): int {
        return $this->id;
    }

    public function setId(int $id): void {
        $this->id = $id;
    }
    
}
