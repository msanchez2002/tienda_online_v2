<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class QuiSomController extends AbstractController
{
    #[Route('/quisom', name: 'app_qui_som')]
    public function index(): Response
    {
        return $this->render('qui_som/index.html.twig', [
            'controller_name' => 'QuiSomController',
        ]);
    }
}
