<?php

namespace App\Controller;

use App\Entity\Perro;
use PDO;
use PDOException;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;



class carritoController extends AbstractController{

  #[Route('/carrito', name: 'app_carrito')]
  public function index(Request $request): Response{

    $session = $request->getSession();
    $arrayPerrosCarrito = array();
    

    $hostname = 'mariadb';
    $nombreUsuario = 'user';
    $contraseña = '';
    $nombreBaseDatos = 'mariadb_db';

    $nombreConexion = mysqli_connect($hostname, $nombreUsuario, $contraseña);
    mysqli_select_db($nombreConexion, $nombreBaseDatos);
    $result = mysqli_query($nombreConexion, "SELECT * FROM Perros WHERE NoVendido = 1");

    $numPerros = $result->num_rows;
    $arrayPerros = array();
    for ($i = 0; $i < $numPerros; $i++) {
      mysqli_data_seek($result, $i);
      $extraido = mysqli_fetch_array($result);

      $arrayPerros[] = new Perro(
        $extraido['id'], $extraido['Nombre'], $extraido['Edad'],
        $extraido['Raza'], $extraido['Descripcion'], $extraido['Precio'],
        $extraido['Descuento'], $extraido['NoVendido']
      );

    }
    mysqli_free_result($result);
    mysqli_close($nombreConexion);


    $perrosCarrito = [];

    if (isset($_POST['id'])) {
      $id = $_POST['id'];
      $arrayPerrosCarrito = $session->get('perrosCarrito', []);
      $perroExistente = false;
  
      foreach ($arrayPerrosCarrito as $perroCarrito) {
          if ($perroCarrito->getId() == $id) {
              // El perro ya está en el carrito
              $perroExistente = true;
              break;
          }
      }
  
      if (!$perroExistente) {
          // Busca el perro en el array de perros
          foreach ($arrayPerros as $perro) {
              if ($perro->getId() == $id) {
                  // Agrega el perro al carrito
                  $arrayPerrosCarrito[] = $perro;
                  $session->set('perrosCarrito', $arrayPerrosCarrito);
                  break;
              }
          }
      }
  

  
      return $this->render('carrito/carrito.html.twig', [
          'ArrayPerros' => $session->get('perrosCarrito', []),
      ]);
  }

  if (isset($_POST['eliminado'])) {
    
    $perrosCarrito = $session->get('perrosCarrito', []);
    
    foreach ($perrosCarrito as $index => $perro) {
      $id = $perro->getId();
      if ($id == $_POST['eliminado']) {
          unset($perrosCarrito[$index]);
      }
  }
  $session->set('perrosCarrito', $perrosCarrito);

    return $this->render('carrito/carrito.html.twig', [
      'ArrayPerros' => $session->get('perrosCarrito', []),
  ]);
}

    return $this->render('carrito/carrito.html.twig',[
      'ArrayPerros' => $session->get('perrosCarrito', []),
    ]);
  }

  #[Route('/carrito/finalizarCompra', name: 'actualizar_noVendido')]
  public function actualizarNoVendido(Request $request): Response{

    $session = $request->getSession();

    $arrayPerrosCarrito = $session->get('perrosCarrito');

    $dsn = 'mysql:host=mariadb;dbname=mariadb_db';
    $nombreUsuario = 'user';
    $contraseña = '';

    try {
      $pdo = new PDO($dsn, $nombreUsuario, $contraseña);
      $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  } catch (PDOException $e) {
      echo "Error: " . $e->getMessage();
  }

  // Consulta de actualización
  $sql = "UPDATE Perros SET NoVendido = '0' WHERE id = :id;";

  $stmt = $pdo->prepare($sql);

  // Valores para actualizar
  foreach ($arrayPerrosCarrito as $perro) {
    $idPerro = $perro->getId();
    $stmt->bindParam(':id', $idPerro);
    $stmt->execute();
}

$session->remove('perrosCarrito');


 return $this->render('carrito/index.html.twig');

}

#[Route('/compra', name: 'app_compra')]
    public function Compra(): Response{
        return $this->render('carrito/index.html.twig');
    }

}