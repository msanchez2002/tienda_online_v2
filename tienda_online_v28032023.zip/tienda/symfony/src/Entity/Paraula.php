<?php

namespace App\Entity;

use App\Repository\ParaulaRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: ParaulaRepository::class)]
class Paraula
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 60)]
    private ?string $paraula = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getParaula(): ?string
    {
        return $this->paraula;
    }

    public function setParaula(string $paraula): self
    {
        $this->paraula = $paraula;

        return $this;
    }
}
