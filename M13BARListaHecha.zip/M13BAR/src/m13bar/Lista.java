/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package m13bar;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

/**
 *
 * @author Xavi
 */
public class Lista extends JFrame {
    private DefaultListModel<String> modeloLista;

    public Lista() {
    super("Lista con botón de eliminar");
        modeloLista = new DefaultListModel<String>();

        // Agregar algunos elementos de ejemplo
        modeloLista.addElement("Elemento 1");
        modeloLista.addElement("Elemento 2");
        modeloLista.addElement("Elemento 3");

        // Crear el JList y asignar el modelo
        JList<String> lista = new JList<String>(modeloLista);

        // Crear el botón de eliminar y agregar un ActionListener
        JButton botonEliminar = new JButton("Eliminar");
        botonEliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Obtener el elemento seleccionado en la lista
                String seleccionado = lista.getSelectedValue();
                // Si se seleccionó algo, eliminarlo del modelo de la lista
                if (seleccionado != null) {
                    modeloLista.removeElement(seleccionado);
                }
            }
        });

        // Crear el panel que contendrá la lista y el botón
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.add(new JScrollPane(lista), BorderLayout.CENTER);
        panel.add(botonEliminar, BorderLayout.SOUTH);

        // Agregar el panel al contenedor principal
        getContentPane().add(panel);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 200);
        setVisible(true);
    }

     public static void main(String[] args) {
        new Lista();
    }
    
}
