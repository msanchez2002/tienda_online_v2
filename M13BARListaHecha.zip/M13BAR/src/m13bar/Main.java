package m13bar;
public class Main {
    public static void main(String[] args) {
        new PantallaLogin().setVisible(true);
    }
    
}
