package m13_actfinal;

import java.time.LocalDate;
import java.sql.Timestamp;

public class Factura {
    int id;
    Timestamp date;
    float precioTotal;
    float IVA;

    public Factura() {
    }

    public Factura(Timestamp date, float precioTotal) {
        this.date = date;
        this.precioTotal = precioTotal;
        this.IVA = 0.21f;
    }

    public Factura(int id, Timestamp date, float precioTotal) {
        this.id = id;
        this.date = date;
        this.precioTotal = precioTotal;
        this.IVA = 0.21f;
    }

    public Factura(Timestamp date, float precioTotal, float IVA) {
        this.date = date;
        this.precioTotal = precioTotal;
        this.IVA = IVA;
    }
    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Timestamp getDate() {
        return date;
    }

    public void setDate(Timestamp date) {
        this.date = date;
    }

    public float getPrecioTotal() {
        return precioTotal;
    }

    public void setPrecioTotal(float precioTotal) {
        this.precioTotal = precioTotal;
    }

    public float getIVA() {
        return IVA;
    }

    public void setIVA(float IVA) {
        this.IVA = IVA;
    }

    @Override
    public String toString() {
        return "Factura{" + "date=" + date + ", precioTotal=" + precioTotal + ", IVA=" + IVA + '}';
    }
    
}
