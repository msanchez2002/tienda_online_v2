package m13_actfinal;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ProductoDAOImpl {

    public ProductoDAOImpl() {
    }

    public void insertarProducto(Producto p) throws SQLException, ClassNotFoundException {
        // Conectar a la base de datos
        Connexio conexion = new Connexio();

        // Preparar la sentencia SQL
        String sql = "INSERT INTO productos (nombre, precio, categoria) VALUES (?, ?, ?)";
        PreparedStatement sentencia = conexion.prepararSentencia(sql);
        sentencia.setString(1, p.getNombre());
        sentencia.setFloat(2, p.getPrecio());
        sentencia.setString(3, p.getCategoria());

        // Ejecutar la sentencia
        sentencia.executeUpdate();

        // Cerrar la conexión a la base de datos
        conexion.cerrar();
    }

    public void eliminarProducto(String text) throws SQLException, ClassNotFoundException {
        Connexio conexion = new Connexio();

        // Preparar la sentencia SQL
        String sql = "DELETE FROM productos WHERE nombre=?";
        PreparedStatement sentencia = conexion.prepararSentencia(sql);
        sentencia.setString(1, text);

        // Ejecutar la sentencia
        sentencia.executeUpdate();

        // Cerrar la conexión a la base de datos
        conexion.cerrar();
    }

    public List<Producto> obtenerProductos() throws SQLException, ClassNotFoundException {
        List<Producto> lista = new ArrayList();

        Connexio conexion = new Connexio();

        String sql = "SELECT nombre, precio, categoria FROM productos ORDER BY categoria, nombre";
        Statement statement = conexion.createStatement();
        ResultSet resultSet = statement.executeQuery(sql);

        // Agregar los resultados a la tabla
        while (resultSet.next()) {
            lista.add(new Producto(resultSet.getString(1), resultSet.getFloat(2), resultSet.getString(3)));
        }

        // Cerrar la conexión a MySQL
        resultSet.close();
        statement.close();
        conexion.cerrar();

        return lista;
    }

    public String[] obtenerCategoriaProductos() throws SQLException, ClassNotFoundException {
        List<String> listaTemp = new ArrayList();
        Connexio conexion = new Connexio();

        String sql = "SELECT DISTINCT(categoria) FROM productos ORDER BY categoria";
        Statement statement = conexion.createStatement();
        ResultSet resultSet = statement.executeQuery(sql);

        // Agregar los resultados a la tabla
        while (resultSet.next()) {
            listaTemp.add(resultSet.getString(1));
        }

        String[] lista = new String[listaTemp.size()];
        for (int i = 0; i < listaTemp.size(); i++) {
            lista[i] = listaTemp.get(i);
        }

        // Cerrar la conexión a MySQL
        resultSet.close();
        statement.close();
        conexion.cerrar();

        return lista;
    }

    public float precioProducto(String nombre) throws SQLException, ClassNotFoundException {
        float precio = 0;
        
        Connexio conexion = new Connexio();

        String sql = "SELECT precio FROM productos WHERE nombre=?";
        PreparedStatement sentencia = conexion.prepararSentencia(sql);
        sentencia.setString(1, nombre);
        ResultSet resultSet = sentencia.executeQuery();

        // Agregar los resultados a la tabla
        if (resultSet.next()) {
            precio = resultSet.getFloat(1);
        }

        // Cerrar la conexión a MySQL
        resultSet.close();
        sentencia.close();
        conexion.cerrar();

        conexion.cerrar();

        return precio;
    }
    
    public int obtenerIdProductoPorNombre(String nombre) throws SQLException, ClassNotFoundException {
        int id = 0;
        
        Connexio conexion = new Connexio();

        String sql = "SELECT id FROM productos WHERE nombre=?";
        PreparedStatement sentencia = conexion.prepararSentencia(sql);
        sentencia.setString(1, nombre);
        ResultSet resultSet = sentencia.executeQuery();

        // Agregar los resultados a la tabla
        if (resultSet.next()) {
            id = resultSet.getInt(1);
        }

        // Cerrar la conexión a MySQL
        resultSet.close();
        sentencia.close();
        conexion.cerrar();

        conexion.cerrar();

        return id;
    }
    
    public Producto obtenerProductoPorId(int id) throws SQLException, ClassNotFoundException {
        Producto p = null;
        
        Connexio conexion = new Connexio();

        String sql = "SELECT nombre,precio,categoria FROM productos WHERE id=?";
        PreparedStatement sentencia = conexion.prepararSentencia(sql);
        sentencia.setInt(1, id);
        ResultSet resultSet = sentencia.executeQuery();

        // Agregar los resultados a la tabla
        if (resultSet.next()) {
            p = new Producto(resultSet.getString(1), resultSet.getFloat(2), resultSet.getString(3));
        }

        // Cerrar la conexión a MySQL
        resultSet.close();
        sentencia.close();
        conexion.cerrar();

        conexion.cerrar();

        return p;
    }
    
    public boolean modificarProductoPorId(int id, Producto p) throws SQLException, ClassNotFoundException {
        boolean modificado = false;
        
        Connexio conexion = new Connexio();

        String sql = "UPDATE productos SET nombre=?, precio=?, categoria=? WHERE id=?";
        PreparedStatement sentencia = conexion.prepararSentencia(sql);
        sentencia.setString(1, p.getNombre());
        sentencia.setFloat(2, p.getPrecio());
        sentencia.setString(3, p.getCategoria());
        sentencia.setInt(4, id);
        sentencia.executeUpdate();
        
        modificado = true;

        sentencia.close();
        conexion.cerrar();

        conexion.cerrar();

        return modificado;
    }

}
