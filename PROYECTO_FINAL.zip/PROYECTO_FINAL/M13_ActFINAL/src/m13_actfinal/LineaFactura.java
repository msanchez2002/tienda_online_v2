package m13_actfinal;

public class LineaFactura {
    int id;
    int idFactura;
    int idProducto;
    int cantidad;
    float precio;

    public LineaFactura() {
    }

    public LineaFactura(int idFactura, int idProducto, int cantidad, float precio) {
        this.idFactura = idFactura;
        this.idProducto = idProducto;
        this.cantidad = cantidad;
        this.precio = precio;
    }

    public LineaFactura(int id, int idFactura, int idProducto, int cantidad, float precio) {
        this.id = id;
        this.idFactura = idFactura;
        this.idProducto = idProducto;
        this.cantidad = cantidad;
        this.precio = precio;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdFactura() {
        return idFactura;
    }

    public void setIdFactura(int idFactura) {
        this.idFactura = idFactura;
    }

    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "LineaFactura{" + "id=" + id + ", idFactura=" + idFactura + ", idProducto=" + idProducto + ", cantidad=" + cantidad + ", precio=" + precio + '}';
    }
    
}
