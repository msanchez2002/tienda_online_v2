CREATE TABLE Productos(
	id int auto_increment,
    nombre varchar(50) not null,
    precio float not null,
    categoria varchar(20) not null,
    CONSTRAINT pk_id_producto PRIMARY KEY (id),
    CONSTRAINT uq_nombre_producto UNIQUE (nombre)
);
/*
drop table productos;
*/

insert into productos (nombre, precio, categoria) values ('Coca-cola', 0.65,'Bebidas');
insert into productos (nombre, precio, categoria) values ('Fanta Limon', 0.75,'Bebidas');
insert into productos (nombre, precio, categoria) values ('Bocadillo de Lomo', 3.95,'Bocadillo');
insert into productos (nombre, precio, categoria) values ('Bocadillo de Jamon', 4.95,'Bocadillo');
insert into productos (nombre, precio, categoria) values ('Macarrones', 5.95,'Plato');
insert into productos (nombre, precio, categoria) values ('Ensalada',3.95,'Plato');

CREATE TABLE Usuarios(
	id int auto_increment,
    nombre varchar(50) not null,
    contrasena varchar(50) not null,
    administrador boolean default 0,
    CONSTRAINT pk_id_usuario PRIMARY KEY (id),
    CONSTRAINT uq_nombre_usuario UNIQUE (nombre)
);
/*
drop table usuarios;
*/

insert into usuarios (nombre, contrasena, administrador) values ('admin', MD5('1234'), 1);
insert into usuarios (nombre, contrasena, administrador) values ('empleado1', MD5('1234'), 0);

CREATE TABLE Facturas (
  id INT AUTO_INCREMENT,
  Fecha timestamp not null,
  PrecioTotal DECIMAL(10, 2) not null,
  IVA DECIMAL(10, 2) not null default 0.21,
  CONSTRAINT pk_id_factura PRIMARY KEY (id)
);
/*
drop table Facturas;
select * from facturas;
*/

CREATE TABLE Lineas_Factura (
  id INT AUTO_INCREMENT,
  idFactura INT not null,
  idProducto INT not null,
  Cantidad INT not null,
  Precio DECIMAL(10, 2) not null,
  CONSTRAINT pk_id_lineas_factura PRIMARY KEY (id),
  FOREIGN KEY (idFactura) REFERENCES Facturas(id),
  FOREIGN KEY (idProducto) REFERENCES Productos(id)
);
/*
drop table Lineas_Factura;
select * from Lineas_Factura;
*/