package m13_actfinal;

import java.sql.*;

public class Connexio {
    private Connection connexio;
    
    public Connexio() throws SQLException, ClassNotFoundException {
        // Cargar el driver de MySQL
        Class.forName("com.mysql.cj.jdbc.Driver");
        
        // Conectar a la base de datos
        String url = "jdbc:mysql://localhost:3306/m13";
        String usuario = "root";
        String contrasena = "1234";
        connexio = DriverManager.getConnection(url, usuario, contrasena);
    }
    
    public void cerrar() throws SQLException {
        connexio.close();
    }
    
    public PreparedStatement prepararSentencia(String sql) throws SQLException {
        return connexio.prepareStatement(sql);
    }
    
    public Statement createStatement() throws SQLException {
        return connexio.createStatement();
    }
    
}

